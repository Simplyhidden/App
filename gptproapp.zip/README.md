# 📚 Personal Study Performance Analyzer

A Python-based web app for tracking and analyzing your study habits, grades, physical activity, and getting AI-powered insights.

---

## 🚀 Quick Start (VS Code)

### 1. Prerequisites
- Python 3.10 or newer
- VS Code with Python extension

### 2. Setup

```bash
# Open the study_analyzer folder in VS Code terminal

# Create a virtual environment
python -m venv venv

# Activate it
# Windows:
venv\Scripts\activate
# Mac/Linux:
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt
```

### 3. Run the app

```bash
streamlit run app.py
```

The app will open automatically at **http://localhost:8501**

---

## 🗂️ Project Structure

```
study_analyzer/
├── app.py                  ← Main entry point
├── requirements.txt
├── data/
│   └── study_analyzer.db   ← SQLite DB (auto-created)
├── pages/
│   ├── dashboard.py        ← Overview + KPIs + radar chart
│   ├── profile.py          ← User setup + subjects
│   ├── daily_log.py        ← Daily study session logger
│   ├── performance.py      ← Grades + trend analysis
│   ├── physical.py         ← Exercise + sleep tracking
│   ├── ai_insights.py      ← AI chat + weekly reports
│   ├── comparisons.py      ← Self vs benchmark vs topper
│   └── goals.py            ← Goal setting + streak tracker
└── utils/
    ├── database.py         ← All SQLite CRUD operations
    ├── ai_engine.py        ← Rule-based + Claude API AI
    ├── charts.py           ← All Plotly chart builders
    └── session.py          ← Streamlit session state
```

---

## 🗄️ Database Schema

| Table | Key Fields |
|-------|-----------|
| `users` | id, name, course |
| `subjects` | user_id, name, interest_level, target_grade |
| `study_logs` | user_id, subject_id, log_date, hours_studied, productivity, topics_covered |
| `grades` | user_id, subject_id, grade, assessment, grade_date |
| `physical_logs` | user_id, log_date, steps, exercise_mins, sleep_hours |
| `goals` | user_id, title, target_date, achieved |
| `streaks` | user_id, current_streak, longest_streak, last_log_date |

---

## 🤖 AI Features

### Layer 1 – Rule-Based (no API key needed)
- Pattern detection (improving / stable / declining)
- Burnout risk scoring
- Consistency measurement
- Subject-level weakness detection
- Radar chart scoring across 8 axes

### Layer 2 – Claude AI (optional, requires API key)
- Interactive chat with your study coach
- Personalized weekly reports
- Context-aware advice based on your actual data

**To enable AI chat:**
1. Go to **AI Insights** page
2. Enter your Anthropic API key (get one at https://console.anthropic.com)
3. Chat with your personal AI coach!

---

## 📊 Radar Chart Axes

| Axis | What it measures |
|------|-----------------|
| Study Consistency | How many of last 7 days you studied |
| Subject Mastery | Average latest grade across subjects |
| Focus Level | Average self-rated productivity |
| Physical Activity | Exercise minutes + daily steps |
| Productivity | Directly from daily logs |
| Time Management | Whether daily hours are in optimal range |
| Improvement Rate | Trend vs previous week |
| Overall Performance | Weighted composite of all axes |

---

## 🔒 Privacy
- All data is stored **locally** in `data/study_analyzer.db`
- API keys are held only in session memory, never saved to disk
- No data is sent anywhere unless you use the AI chat feature

---

## 💡 Tips
- Log data **every day** for the best insights
- Add at least 3 subjects for meaningful radar chart analysis
- Record grades after every test/quiz for accurate trend tracking
- The physical activity correlation chart needs 7+ days of both study and physical logs

---

## 🌐 Enhanced Online Features

This edition preserves the original local Study Analyzer and adds optional shared online features: Online Account, same-course student comparison, public chat and 1v1 battles. See `SETUP_ONLINE.md` for the one-time online configuration and use `start.bat` for one-click Windows startup.
