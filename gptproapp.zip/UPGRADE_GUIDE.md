# Study Analyzer — upgrade guide

## What is preserved
The original Streamlit layout, sidebar style, existing pages, chart palette and local SQLite data model remain. Learning Path is one additional page. AI Insights gains a mode selector; there is no visual redesign.

## Run it
Extract the ZIP, open the folder and double-click start.bat on Windows. The first launch installs Python packages; following launches reuse them. For macOS/Linux: create a Python venv, install requirements.txt, then run `python -m streamlit run app.py`. Start from this folder. Existing users should back up and copy their old data/study_analyzer.db into the new data folder with the app stopped. Schema additions are non-destructive. Do not share a live SQLite file through a sync drive.

## Features added
- Personal learning goal, deadline and daily time budget.
- Gap analysis using latest grades versus subject targets; missing grades stay unknown.
- Seven-day pathway with diagnostic, learning, practice and recall tasks.
- Priorities respond to subject interest and self-reported recall confidence. Rebuild explicitly after new evidence; completed tasks are retained. Confidence is not a validated assessment. Add real assessment grades separately.
- Offline operation for analytics/planning and optional in-process local LLM inference.
- Downloadable plan and measured inference information for a SoC demonstration.
- Cloud chat is opt-in with a data-sharing checkbox; cloud failure leaves local work intact.

## Bugs corrected
First-day streaks, stale streaks and historical backfills; calendar-window queries previously treated row counts as days; duplicate latest grades on the same date; deletion of subjects with linked records; profile/chat state mixing; profile selector collisions; repeated dependency downloads on startup; stale chat messages showing the oldest page; online client authentication lost between reruns; SQL scoring incorrectly reading answers from sanitized questions; direct score editing permissions; year collisions in weekly charts. Daily logs now load existing hours/topics and can be corrected to zero. Unfinished plans preserve completed evidence and obey remaining daily budgets. Manual class benchmarks and simulated ranking remain labelled estimates.

## Online features
For a NEW Supabase project, run supabase_schema.sql followed by supabase_upgrade.sql. For an EXISTING project, back up first and run supabase_upgrade.sql. Configure the public URL and anon key as described in SETUP_ONLINE.md; never put a service-role key in the app. The upgrade removes direct battle/score write policies and uses validated RPCs. Cloud services were not exercised against a live account here. SQL must be checked in a staging project before a shared deployment.

Battle questions are still created by the initiating client: this is a casual practice feature, NOT a cheating-resistant ranked examination. The creator may know answers. Waiting battles currently remain in the database after leaving. Before public rollout, add server-owned question banks, waiting-room expiry, rate limits, moderation and independent database permission tests. Profile directory access remains available to signed-in community users; local profiles are a convenience selector, not authentication. Bind locally (the supplied default); do not host the local profile selector publicly as-is.

## Match to the attached mailer
| Mailer requirement | This build | Evidence still needed |
|---|---|---|
| Education: on-device personalised learning assistant | Offline adaptive planner plus actual optional local-model inference path | Run a downloaded model successfully on the chosen target device |
| AI-enabled prototype on SoC | CPU inference implementation and architecture/model/memory/time export | Arm hardware deployment and reproducible measurements |
| Processor, memory, accelerator and software-stack understanding | Configurable CPU threads and observable runtime data | Compare configurations; explain trade-offs; no GPU/NPU acceleration implemented |
| Virtual qualifying and PoC phases; team 1–3 | Application source and demo procedure supplied | Team registration and organiser deliverables |

The announcement is a high-level mailer: it does not specify Llama, ExecuTorch, Android, exact model, evaluation metrics or detailed submission artefacts. These should not be inferred from it. Earlier Android/ExecuTorch requirements are NOT implemented by this Streamlit build. Confirm the current detailed rules before deciding the final deployment platform.

## Validation and limits
Run `python -m unittest discover -s tests -v` from the project folder. Core regression tests cover streak/backfill, date windows, tied grades, deletion, missing evidence, plan budget and adaptive feedback. Streamlit AppTest visits every navigation entry with a test profile. It exercises local pages and unconfigured-online states, not live Supabase or actual model generation. No model weights, API account, Arm hardware, native Android build or measured device performance were available for validation. This is an upgraded prototype, not a claim of zero bugs or contest certification.

## Suggested demo
1. Create profile and three subjects with different targets/interests.
2. Enter dated assessment scores and study logs; inspect unchanged dashboard/radar.
3. Set an exam goal, deadline and 60-minute budget; generate a plan.
4. Complete a session with low recall confidence; rebuild and show the changed priority explanation.
5. Run a real local model without internet and export its measurements.
6. Explain the target SoC, quantization, memory constraints and measured latency; keep cloud/community features optional.
