# Local AI setup

The app remains usable without model weights or an API key. Offline guidance is rule-based, not an LLM. Local AI is a separate, real inference path through llama-cpp-python; it does not call a remote endpoint or silently fall back to cloud.

1. Run the base app once with start.bat (Python 3.10+). Initial dependency installation needs internet. Later starts reuse the environment.
2. Activate the venv and install `pip install -r requirements-local-ai.txt`. A native C/C++ build toolchain may be needed for llama-cpp-python on your OS.
3. Obtain a compatible instruction-tuned GGUF model from its official publisher or a verified conversion. Review its licence and hardware requirements. Model weights are NOT included. Use a small quantized model that fits your device; validate output quality before choosing it for submission.
4. Set `STUDY_MODEL_PATH` to the full model path before starting Streamlit. Windows command prompt: `set "STUDY_MODEL_PATH=C:\models\model.gguf"`. Optional: `set STUDY_MODEL_THREADS=4`.
5. In AI Insights select Local AI model. The first message loads weights; later messages reuse the model. A lock serializes inference. CPU execution is deliberate; no accelerator performance is claimed.
6. Open Local inference measurements and download the benchmark after a successful response. Measurements include architecture, model file size, initial load time, response duration and output tokens. Install psutil for process RSS after inference. RSS is NOT peak model memory; output tokens divided by response time is NOT isolated decoding throughput. Timing includes queue/prompt overhead.

Run on an Arm Linux host to evaluate the CPU path on an Arm SoC, subject to build and memory compatibility. A browser on an Android phone connected to a laptop still runs inference on the laptop. This package is not an APK, does not contain ExecuTorch, and has not been tested on an Arm board or phone. If the detailed challenge rules require Android/ExecuTorch, a native port and model export are still necessary.

For the demonstration, preload dependencies and model, disconnect internet, create a profile, record grades, generate a learning plan, complete a session, rebuild it and ask the local coach a question. Export benchmarks over repeated runs, recording SoC model, RAM, OS, model/quantization, threads, cold/warm conditions and power/thermal observations. Do not label desktop numbers as phone benchmarks.

API reference used for the implementation: https://llama-cpp-python.readthedocs.io/en/latest/api-reference/
