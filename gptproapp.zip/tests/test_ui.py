import tempfile, unittest
from pathlib import Path
from streamlit.testing.v1 import AppTest
from utils import database as db

class SmokeTests(unittest.TestCase):
    def test_navigation(self):
        with tempfile.TemporaryDirectory() as tmp:
            old=db.DB_PATH;db.DB_PATH=Path(tmp)/'app.db'
            try:
                db.init_db();uid=db.create_user('UI Test','EXTC');db.add_subject(uid,'DSP')
                at=AppTest.from_file(str(Path(__file__).resolve().parents[1]/'app.py'),default_timeout=30)
                at.session_state['user_id']=uid
                at.run()
                choices=at.sidebar.radio[0].options
                for choice in choices:
                    at.sidebar.radio[0].set_value(choice).run()
                    self.assertFalse(list(at.exception),f'{choice}: {list(at.exception)}')
                    if choice == '🎯 Learning Path':
                        at.text_input[0].set_value('Pass DSP exam')
                        at.button[0].click().run()
                        self.assertFalse(list(at.exception))
                        from utils.learning import tasks
                        self.assertEqual(len(tasks(uid)),7)
            finally:db.DB_PATH=old
if __name__=='__main__':unittest.main()
