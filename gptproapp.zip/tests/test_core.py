import tempfile, unittest
from pathlib import Path
from datetime import date,timedelta
from utils import database as db
from utils import learning
from utils.ai_engine import analyze_study_patterns

class CoreTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.old=db.DB_PATH
        db.DB_PATH=Path(self.tmp.name)/'test.db';db.init_db()
        self.uid=db.create_user('Test','EXTC');self.sid=db.add_subject(self.uid,'DSP')
        learning.init_learning()
    def tearDown(self):
        db.DB_PATH=self.old;self.tmp.cleanup()
    def log(self,days):
        db.log_study(self.uid,self.sid,str(date.today()-timedelta(days=days)),1,7,[])
    def test_streak_backfill(self):
        self.log(0);self.assertEqual(db.get_streak(self.uid)['current_streak'],1)
        self.log(2);self.log(1);self.log(0)
        self.assertEqual(db.get_streak(self.uid)['current_streak'],3)
    def test_expired_streak(self):
        self.log(3);self.assertEqual(db.get_streak(self.uid)['current_streak'],0)
        self.assertEqual(db.get_streak(self.uid)['longest_streak'],1)
    def test_real_calendar_window(self):
        self.log(45);self.log(0)
        self.assertEqual(len(db.get_study_logs(self.uid,30)),1)
        self.assertEqual(len(db.get_daily_totals(self.uid,30)),1)
    def test_latest_tie(self):
        for g in [40,90]:db.add_grade(self.uid,self.sid,g,'test',str(date.today()))
        rows=db.get_latest_grade_per_subject(self.uid)
        self.assertEqual(len(rows),1);self.assertEqual(rows[0]['grade'],90)
    def test_delete_with_history(self):
        self.log(0);db.add_grade(self.uid,self.sid,40,'test',str(date.today()))
        db.delete_subject(self.sid);self.assertEqual(db.get_study_logs(self.uid),[])
    def test_old_logs_not_consistent(self):
        self.log(20)
        self.assertEqual(analyze_study_patterns(db.get_daily_totals(self.uid),[])['consistency_score'],0)
    def test_adaptive_budget_and_completion(self):
        second=db.add_subject(self.uid,'AWP');learning.save_settings(self.uid,'Exam',45,str(date.today()+timedelta(days=7)))
        learning.generate_plan(self.uid);tasks=learning.tasks(self.uid)
        for day in {t['study_date'] for t in tasks}:
            self.assertEqual(sum(t['minutes'] for t in tasks if t['study_date']==day),45)
        t=tasks[0];learning.complete(self.uid,t['id'],1);learning.generate_plan(self.uid)
        self.assertTrue(any(x['id']==t['id'] and x['done'] for x in learning.tasks(self.uid)))
        self.assertIn('confidence 1/5',next(x for x in learning.gaps(self.uid) if x['id']==t['subject_id'])['reason'])
    def test_no_invented_assessment(self):
        self.assertIsNone(learning.gaps(self.uid)[0]['latest'])

if __name__=='__main__':unittest.main()
