"""
utils/ai_engine.py

Two-layer AI system:
  Layer 1 – Rule-based analytics (always runs, no API key needed)
  Layer 2 – Claude API for rich natural-language insights (optional)
"""

from __future__ import annotations
import os, json
from datetime import date, timedelta
from typing import Optional

# ─────────────────────────── RULE-BASED ENGINE ──────────────────────────────

def analyze_study_patterns(daily_totals: list, study_summary: list) -> dict:
    """Return structured insights from raw data."""
    if not daily_totals:
        return {"status": "no_data"}

    hours = [d["total_hours"] for d in daily_totals]
    prod  = [d["avg_productivity"] for d in daily_totals if d["avg_productivity"]]

    avg_hours = sum(hours) / len(hours) if hours else 0
    avg_prod  = sum(prod)  / len(prod)  if prod  else 0

    # Consistency score: how many of last 7 days had study > 0
    recent_7 = [d for d in daily_totals if 0 <= (date.today()-date.fromisoformat(d["log_date"])).days < 7]
    days_studied = len([d for d in recent_7 if d["total_hours"] > 0])
    consistency  = (days_studied / 7) * 10  # 0-10

    # Trend: compare last 7 days avg vs previous 7
    prev_7 = [d for d in daily_totals if 7 <= (date.today()-date.fromisoformat(d["log_date"])).days < 14]
    recent_avg = sum(d["total_hours"] for d in recent_7) / 7
    prev_avg   = sum(d["total_hours"] for d in prev_7)   / 7

    if prev_avg == 0:
        trend = "improving" if recent_avg > 0 else "no_data"
    elif recent_avg > prev_avg * 1.1:
        trend = "improving"
    elif recent_avg < prev_avg * 0.9:
        trend = "declining"
    else:
        trend = "stable"

    # Burnout risk: very high hours + low productivity
    burnout_risk = "low"
    if avg_hours > 8 and avg_prod < 5:
        burnout_risk = "high"
    elif avg_hours > 6 and avg_prod < 6:
        burnout_risk = "medium"

    # Subject-level insights
    weak_subjects  = [s["subject_name"] for s in study_summary if (s["avg_hours"] or 0) < 1.0]
    strong_subjects = sorted(study_summary, key=lambda s: s["avg_hours"] or 0, reverse=True)[:2]

    return {
        "avg_daily_hours":   round(avg_hours, 2),
        "avg_productivity":  round(avg_prod,  2),
        "consistency_score": round(consistency, 1),
        "trend":             trend,
        "burnout_risk":      burnout_risk,
        "weak_subjects":     weak_subjects,
        "strong_subject_names": [s["subject_name"] for s in strong_subjects],
    }


def compute_radar_scores(
    study_summary: list,
    daily_totals: list,
    grades: list,
    physical_logs: list,
    patterns: dict,
) -> dict:
    """Return 8 axes for the radar chart, each 0-10."""

    def _safe(val, lo, hi):
        return max(0, min(10, (val - lo) / (hi - lo) * 10)) if hi != lo else 5

    # 1. Study Consistency (0-10 from patterns)
    consistency = patterns.get("consistency_score", 5)

    # 2. Subject Mastery – average of latest grades normalised to 10
    if grades:
        avg_grade = sum(g["grade"] for g in grades) / len(grades)
        mastery = _safe(avg_grade, 0, 100)
    else:
        mastery = 5

    # 3. Focus Level – avg productivity
    focus = patterns.get("avg_productivity", 5)

    # 4. Physical Activity – based on exercise_mins and steps
    if physical_logs:
        avg_exercise = sum(p["exercise_mins"] for p in physical_logs) / len(physical_logs)
        avg_steps    = sum(p["steps"]         for p in physical_logs) / len(physical_logs)
        phys = (_safe(avg_exercise, 0, 60) + _safe(avg_steps, 0, 10000)) / 2
    else:
        phys = 5

    # 5. Productivity (direct from patterns)
    productivity = patterns.get("avg_productivity", 5)

    # 6. Time Management – are avg hours in a healthy range (2-6)?
    avg_h = patterns.get("avg_daily_hours", 0)
    if 2 <= avg_h <= 6:
        time_mgmt = 9
    elif avg_h < 1:
        time_mgmt = 3
    elif avg_h > 8:
        time_mgmt = 5  # too much may indicate poor planning
    else:
        time_mgmt = 7

    # 7. Improvement Rate
    trend = patterns.get("trend", "stable")
    improvement = {"improving": 8, "stable": 5, "declining": 3, "no_data": 5}.get(trend, 5)

    # 8. Overall Performance – weighted composite
    overall = round(
        consistency    * 0.15 +
        mastery        * 0.25 +
        focus          * 0.15 +
        phys           * 0.10 +
        productivity   * 0.10 +
        time_mgmt      * 0.10 +
        improvement    * 0.15,
        2
    )

    return {
        "Study Consistency":  round(consistency,  1),
        "Subject Mastery":    round(mastery,       1),
        "Focus Level":        round(focus,         1),
        "Physical Activity":  round(phys,          1),
        "Productivity":       round(productivity,  1),
        "Time Management":    round(time_mgmt,     1),
        "Improvement Rate":   round(improvement,   1),
        "Overall Performance":round(overall,       1),
    }


def rule_based_insights(patterns: dict, radar: dict, grades: list, subjects: list) -> list[str]:
    """Return a list of human-readable insight strings."""
    tips = []
    if patterns.get("status") == "no_data":
        return ["Log a study session and assessment to get personalised insights. No performance has been inferred yet."]

    trend = patterns.get("trend", "stable")
    if trend == "improving":
        tips.append("📈 Great momentum! Your study hours have been increasing over the past two weeks.")
    elif trend == "declining":
        tips.append("📉 Your study hours have dropped compared to the previous week — try to identify what changed.")
    else:
        tips.append("📊 Your study effort has been consistent. Consider pushing slightly harder to break through plateaus.")

    burnout = patterns.get("burnout_risk")
    if burnout == "high":
        tips.append("🔥 Burnout risk is HIGH. You're averaging many hours with low productivity. Rest is part of the plan — take a break day.")
    elif burnout == "medium":
        tips.append("⚠️ Moderate burnout signals. Ensure you're getting enough sleep and mix in physical activity.")

    cons = patterns.get("consistency_score", 5)
    if cons < 5:
        tips.append("📅 Consistency is low. Aim to study at least 5 out of 7 days, even if only for 30 minutes.")
    elif cons >= 8:
        tips.append("🔥 Excellent consistency streak! Regular study beats last-minute cramming every time.")

    weak = patterns.get("weak_subjects", [])
    if weak:
        tips.append(f"📚 Subjects needing more attention: **{', '.join(weak)}**. Try allocating at least 1 hour each per day.")

    for row in grades:
        gap = row.get("grade", 0) - row.get("target_grade", 80)
        if gap < -15:
            tips.append(f"🎯 **{row['subject_name']}** is significantly below your target. Consider seeking help or changing your study strategy.")
        elif gap >= 0:
            tips.append(f"✅ **{row['subject_name']}** is at or above your target. Keep it up!")

    if radar.get("Physical Activity", 5) < 4:
        tips.append("🏃 Physical activity is very low. Even a 20-minute walk improves focus and memory consolidation.")

    if not tips:
        tips.append("✨ Everything looks balanced! Keep up the good work and log data daily for richer insights.")

    return tips


# ─────────────────────────── CLAUDE API LAYER ───────────────────────────────

def build_context_for_claude(
    user: dict,
    subjects: list,
    patterns: dict,
    radar: dict,
    grades: list,
    goals: list,
) -> str:
    """Build a structured context string to feed to Claude."""
    ctx = {
        "student": {
            "name":    user.get("name"),
            "course":  user.get("course"),
            "subjects": [{"name": s["name"], "interest": s["interest_level"]} for s in subjects],
        },
        "study_patterns": patterns,
        "performance_radar": radar,
        "recent_grades": [
            {"subject": g["subject_name"], "grade": g["grade"], "target": g.get("target_grade")}
            for g in grades[:10]
        ],
        "active_goals": [g["title"] for g in goals if not g["achieved"]],
    }
    return json.dumps(ctx, indent=2)


def ask_claude(context: str, user_question: str, chat_history: list, api_key: str) -> str:
    """
    Call the Anthropic API with full chat history.
    chat_history: list of {"role": "user"|"assistant", "content": str}
    """
    try:
        import anthropic
    except ImportError:
        return "⚠️ `anthropic` package not installed. Run `pip install anthropic` to enable AI chat."

    system_prompt = f"""You are a personal study performance coach and AI analyst.
You have access to the following student data:

{context}

Your job:
- Provide specific, actionable, encouraging advice.
- Reference actual numbers from the data when relevant.
- Keep responses concise (3-5 sentences unless asked for more).
- If you detect burnout risk or declining performance, be empathetic and practical.
- Never be generic. Always personalize to this specific student.
"""

    messages = chat_history + [{"role": "user", "content": user_question}]

    client = anthropic.Anthropic(api_key=api_key)
    response = client.messages.create(
        model="claude-opus-4-5",
        max_tokens=600,
        system=system_prompt,
        messages=messages,
    )
    return response.content[0].text


def generate_weekly_report(context: str, api_key: str) -> str:
    """Generate a structured weekly report using Claude."""
    try:
        import anthropic
    except ImportError:
        return "Install `anthropic` package to generate AI reports."

    prompt = f"""Based on this student data:
{context}

Generate a weekly performance report with:
1. This Week in Numbers (3-4 key metrics)
2. Top Achievement
3. Area Needing Most Work
4. Specific Action Plan for Next Week (3 bullet points)
5. Motivational closing line

Keep it under 250 words. Be specific, not generic."""

    client = anthropic.Anthropic(api_key=api_key)
    response = client.messages.create(
        model="claude-opus-4-5",
        max_tokens=500,
        messages=[{"role": "user", "content": prompt}],
    )
    return response.content[0].text
