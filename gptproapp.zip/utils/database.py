"""
utils/database.py
Full SQLite data layer for the Study Performance Analyzer.
"""

import sqlite3, json, os
from datetime import date, datetime, timedelta
from pathlib import Path

DB_PATH = Path(__file__).parent.parent / "data" / "study_analyzer.db"
DB_PATH.parent.mkdir(exist_ok=True)


def _conn():
    con = sqlite3.connect(str(DB_PATH))
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys = ON")
    return con


# ─────────────────────────── SCHEMA ─────────────────────────────────────────

def init_db():
    with _conn() as con:
        con.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            name        TEXT    NOT NULL,
            course      TEXT    NOT NULL,
            created_at  TEXT    DEFAULT (date('now'))
        );

        CREATE TABLE IF NOT EXISTS subjects (
            id            INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id       INTEGER NOT NULL REFERENCES users(id),
            name          TEXT    NOT NULL,
            interest_level INTEGER DEFAULT 5,   -- 1-10
            target_grade  REAL    DEFAULT 80.0
        );

        CREATE TABLE IF NOT EXISTS study_logs (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id         INTEGER NOT NULL REFERENCES users(id),
            subject_id      INTEGER NOT NULL REFERENCES subjects(id),
            log_date        TEXT    NOT NULL,
            hours_studied   REAL    DEFAULT 0,
            productivity    INTEGER DEFAULT 5,  -- 1-10
            topics_covered  TEXT,               -- JSON list
            created_at      TEXT    DEFAULT (datetime('now'))
        );

        CREATE TABLE IF NOT EXISTS grades (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id     INTEGER NOT NULL REFERENCES users(id),
            subject_id  INTEGER NOT NULL REFERENCES subjects(id),
            grade       REAL    NOT NULL,
            assessment  TEXT,
            grade_date  TEXT    NOT NULL
        );

        CREATE TABLE IF NOT EXISTS physical_logs (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id         INTEGER NOT NULL REFERENCES users(id),
            log_date        TEXT    NOT NULL,
            steps           INTEGER DEFAULT 0,
            exercise_mins   INTEGER DEFAULT 0,
            sleep_hours     REAL    DEFAULT 7.0
        );

        CREATE TABLE IF NOT EXISTS goals (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id     INTEGER NOT NULL REFERENCES users(id),
            title       TEXT    NOT NULL,
            target_date TEXT,
            achieved    INTEGER DEFAULT 0,
            created_at  TEXT    DEFAULT (date('now'))
        );

        CREATE TABLE IF NOT EXISTS streaks (
            user_id         INTEGER PRIMARY KEY REFERENCES users(id),
            current_streak  INTEGER DEFAULT 0,
            longest_streak  INTEGER DEFAULT 0,
            last_log_date   TEXT
        );
        """)


# ─────────────────────────── USERS ──────────────────────────────────────────

def create_user(name: str, course: str) -> int:
    with _conn() as con:
        cur = con.execute("INSERT INTO users (name, course) VALUES (?,?)", (name, course))
        uid = cur.lastrowid
        con.execute("INSERT INTO streaks (user_id) VALUES (?)", (uid,))
        return uid


def get_user(user_id: int):
    with _conn() as con:
        row = con.execute("SELECT * FROM users WHERE id=?", (user_id,)).fetchone()
        return dict(row) if row else None


def list_users():
    with _conn() as con:
        return [dict(r) for r in con.execute("SELECT * FROM users ORDER BY name").fetchall()]


# ─────────────────────────── SUBJECTS ───────────────────────────────────────

def add_subject(user_id: int, name: str, interest: int = 5, target: float = 80.0) -> int:
    with _conn() as con:
        cur = con.execute(
            "INSERT INTO subjects (user_id, name, interest_level, target_grade) VALUES (?,?,?,?)",
            (user_id, name, interest, target)
        )
        return cur.lastrowid


def get_subjects(user_id: int):
    with _conn() as con:
        return [dict(r) for r in
                con.execute("SELECT * FROM subjects WHERE user_id=? ORDER BY name", (user_id,)).fetchall()]


def update_subject(subject_id: int, interest: int, target: float):
    with _conn() as con:
        con.execute("UPDATE subjects SET interest_level=?, target_grade=? WHERE id=?",
                    (interest, target, subject_id))


def delete_subject(subject_id: int):
    with _conn() as con:
        con.execute("DELETE FROM study_logs WHERE subject_id=?", (subject_id,))
        con.execute("DELETE FROM grades WHERE subject_id=?", (subject_id,))
        con.execute("DELETE FROM subjects WHERE id=?", (subject_id,))


# ─────────────────────────── STUDY LOGS ─────────────────────────────────────

def log_study(user_id: int, subject_id: int, log_date: str,
              hours: float, productivity: int, topics: list):
    with _conn() as con:
        # upsert: one log per subject per day
        existing = con.execute(
            "SELECT id FROM study_logs WHERE user_id=? AND subject_id=? AND log_date=?",
            (user_id, subject_id, log_date)
        ).fetchone()
        topics_json = json.dumps(topics)
        if existing:
            con.execute(
                "UPDATE study_logs SET hours_studied=?, productivity=?, topics_covered=? WHERE id=?",
                (hours, productivity, topics_json, existing["id"])
            )
        else:
            con.execute(
                "INSERT INTO study_logs (user_id,subject_id,log_date,hours_studied,productivity,topics_covered) VALUES (?,?,?,?,?,?)",
                (user_id, subject_id, log_date, hours, productivity, topics_json)
            )
    _update_streak(user_id, log_date)


def get_study_logs(user_id: int, days: int = 30):
    with _conn() as con:
        rows = con.execute("""
            SELECT sl.*, s.name AS subject_name
            FROM study_logs sl
            JOIN subjects s ON sl.subject_id = s.id
            WHERE sl.user_id=? AND sl.log_date BETWEEN ? AND ?
            ORDER BY sl.log_date DESC
        """, (user_id, str(date.today()-timedelta(days=days-1)), str(date.today()))).fetchall()
        result = []
        for r in rows:
            d = dict(r)
            d["topics_covered"] = json.loads(d["topics_covered"] or "[]")
            result.append(d)
        return result


def get_study_summary(user_id: int):
    """Aggregate stats per subject."""
    with _conn() as con:
        return [dict(r) for r in con.execute("""
            SELECT s.name AS subject_name, s.interest_level,
                   ROUND(AVG(sl.hours_studied),2) AS avg_hours,
                   ROUND(AVG(sl.productivity),2)  AS avg_productivity,
                   SUM(sl.hours_studied)           AS total_hours,
                   COUNT(sl.id)                    AS sessions
            FROM subjects s
            LEFT JOIN study_logs sl ON sl.subject_id=s.id AND sl.user_id=?
            WHERE s.user_id=?
            GROUP BY s.id
        """, (user_id, user_id)).fetchall()]


def get_daily_totals(user_id: int, days: int = 30):
    with _conn() as con:
        return [dict(r) for r in con.execute("""
            SELECT log_date,
                   ROUND(SUM(hours_studied),2) AS total_hours,
                   ROUND(AVG(productivity),2)  AS avg_productivity
            FROM study_logs
            WHERE user_id=? AND log_date BETWEEN ? AND ?
            GROUP BY log_date
            ORDER BY log_date DESC
        """, (user_id, str(date.today()-timedelta(days=days-1)), str(date.today()))).fetchall()]


# ─────────────────────────── GRADES ─────────────────────────────────────────

def add_grade(user_id: int, subject_id: int, grade: float, assessment: str, grade_date: str):
    with _conn() as con:
        con.execute(
            "INSERT INTO grades (user_id,subject_id,grade,assessment,grade_date) VALUES (?,?,?,?,?)",
            (user_id, subject_id, grade, assessment, grade_date)
        )


def get_grades(user_id: int):
    with _conn() as con:
        return [dict(r) for r in con.execute("""
            SELECT g.*, s.name AS subject_name, s.target_grade
            FROM grades g JOIN subjects s ON g.subject_id=s.id
            WHERE g.user_id=?
            ORDER BY g.grade_date DESC
        """, (user_id,)).fetchall()]


def get_latest_grade_per_subject(user_id: int):
    with _conn() as con:
        return [dict(r) for r in con.execute("""
            SELECT g.subject_id, s.name AS subject_name, s.target_grade,
                   g.grade, g.grade_date
            FROM grades g
            JOIN subjects s ON g.subject_id=s.id
            WHERE g.user_id=?
            AND g.id = (
                SELECT g2.id FROM grades g2
                WHERE g2.subject_id=g.subject_id AND g2.user_id=?
                ORDER BY g2.grade_date DESC, g2.id DESC LIMIT 1
            )
        """, (user_id, user_id)).fetchall()]


# ─────────────────────────── PHYSICAL ───────────────────────────────────────

def log_physical(user_id: int, log_date: str, steps: int, exercise_mins: int, sleep_hours: float):
    with _conn() as con:
        existing = con.execute(
            "SELECT id FROM physical_logs WHERE user_id=? AND log_date=?",
            (user_id, log_date)
        ).fetchone()
        if existing:
            con.execute(
                "UPDATE physical_logs SET steps=?,exercise_mins=?,sleep_hours=? WHERE id=?",
                (steps, exercise_mins, sleep_hours, existing["id"])
            )
        else:
            con.execute(
                "INSERT INTO physical_logs (user_id,log_date,steps,exercise_mins,sleep_hours) VALUES (?,?,?,?,?)",
                (user_id, log_date, steps, exercise_mins, sleep_hours)
            )


def get_physical_logs(user_id: int, days: int = 30):
    with _conn() as con:
        return [dict(r) for r in con.execute("""
            SELECT * FROM physical_logs
            WHERE user_id=? AND log_date BETWEEN ? AND ?
            ORDER BY log_date DESC
        """, (user_id, str(date.today()-timedelta(days=days-1)), str(date.today()))).fetchall()]


# ─────────────────────────── GOALS ──────────────────────────────────────────

def add_goal(user_id: int, title: str, target_date: str = None):
    with _conn() as con:
        con.execute("INSERT INTO goals (user_id,title,target_date) VALUES (?,?,?)",
                    (user_id, title, target_date))


def get_goals(user_id: int):
    with _conn() as con:
        return [dict(r) for r in
                con.execute("SELECT * FROM goals WHERE user_id=? ORDER BY achieved,target_date", (user_id,)).fetchall()]


def mark_goal(goal_id: int, achieved: bool):
    with _conn() as con:
        con.execute("UPDATE goals SET achieved=? WHERE id=?", (int(achieved), goal_id))


# ─────────────────────────── STREAKS ────────────────────────────────────────

def _update_streak(user_id: int, log_date: str):
    # Derive from dated activity: edits/backfills cannot increment a counter incorrectly.
    get_streak(user_id)


def get_streak(user_id: int):
    with _conn() as con:
        dates = [date.fromisoformat(r[0]) for r in con.execute(
            "SELECT DISTINCT log_date FROM study_logs WHERE user_id=? AND hours_studied>0 AND log_date<=? ORDER BY log_date",
            (user_id, str(date.today())))]
        longest = run = 0
        previous = None
        for day in dates:
            run = run+1 if previous and (day-previous).days == 1 else 1
            longest = max(longest, run)
            previous = day
        current = run if previous and (date.today()-previous).days <= 1 else 0
        return {"current_streak": current, "longest_streak": longest,
                "last_log_date": str(previous) if previous else None}
