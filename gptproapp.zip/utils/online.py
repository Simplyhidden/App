import os
import re
from datetime import datetime, timezone
from typing import Optional
import streamlit as st

def _secret(name):
    try:
        value = st.secrets.get(name, "")
        if value:
            return str(value)
    except Exception:
        pass
    return os.getenv(name, "")

def is_configured():
    return bool(_secret("SUPABASE_URL") and _secret("SUPABASE_ANON_KEY"))

def get_client():
    if not is_configured():
        return None
    if st.session_state.get("_online_client") is not None:
        return st.session_state["_online_client"]
    try:
        from supabase import create_client
        client = create_client(_secret("SUPABASE_URL"), _secret("SUPABASE_ANON_KEY"))
        st.session_state["_online_client"] = client
        return client
    except Exception as exc:
        st.error(f"Could not initialize online services: {exc}")
        return None

def course_key(course):
    return re.sub(r"\s+", " ", (course or "").strip().lower())

def online_user_id() -> Optional[str]:
    return st.session_state.get("online_user_id")

def online_profile():
    client, uid = get_client(), online_user_id()
    if not client or not uid:
        return None
    try:
        res = client.table("profiles").select("*").eq("id", uid).limit(1).execute()
        return res.data[0] if res.data else None
    except Exception:
        return None

def sign_up(email, password):
    client = get_client()
    if not client:
        return None, "Online services are not configured yet."
    try:
        res = client.auth.sign_up({"email": email.strip(), "password": password})
        if getattr(res, "user", None) and getattr(res, "session", None):
            st.session_state["online_user_id"] = res.user.id
            st.session_state["online_email"] = email.strip()
            return res.user, None
        if getattr(res, "user", None):
            return res.user, "Account created. Check your email if confirmation is enabled, then sign in."
        return None, "Account could not be created."
    except Exception as exc:
        return None, str(exc)

def sign_in(email, password):
    client = get_client()
    if not client:
        return None, "Online services are not configured yet."
    try:
        res = client.auth.sign_in_with_password({"email": email.strip(), "password": password})
        if getattr(res, "user", None):
            st.session_state["online_user_id"] = res.user.id
            st.session_state["online_email"] = email.strip()
            return res.user, None
        return None, "Invalid login."
    except Exception as exc:
        return None, str(exc)

def sign_out():
    client = get_client()
    try:
        if client:
            client.auth.sign_out()
    except Exception:
        pass
    st.session_state.pop("online_user_id", None)
    st.session_state.pop("online_email", None)
    st.session_state.pop("_online_client", None)
    st.session_state["battle_id"] = None

def save_profile(display_name, username, course, semester):
    client, uid = get_client(), online_user_id()
    if not client or not uid:
        return False, "Please sign in first."
    username = username.strip()
    if not re.fullmatch(r"[A-Za-z0-9_]{3,24}", username):
        return False, "Username must be 3–24 characters using letters, numbers, or _."
    if not display_name.strip() or not course.strip():
        return False, "Display name and course are required."
    try:
        client.table("profiles").upsert({
            "id": uid, "display_name": display_name.strip()[:60],
            "username": username, "course": course.strip()[:120],
            "course_key": course_key(course), "semester": int(semester)
        }, on_conflict="id").execute()
        return True, None
    except Exception as exc:
        return False, str(exc)

def sync_local_metrics(user_id):
    profile, client = online_profile(), get_client()
    if not profile or not client:
        return False, "Complete your online profile first."
    try:
        from utils.database import get_daily_totals, get_latest_grade_per_subject
        from utils.ai_engine import analyze_study_patterns
        daily = get_daily_totals(user_id, 30)
        latest = get_latest_grade_per_subject(user_id)
        patterns = analyze_study_patterns(daily, [])
        avg_grade = round(sum(x["grade"] for x in latest) / len(latest), 2) if latest else None
        total_hours = round(sum(x["total_hours"] or 0 for x in daily), 2)
        avg_productivity = round(sum(x["avg_productivity"] or 0 for x in daily) / len(daily), 2) if daily else None
        client.table("profiles").update({
            "avg_grade": avg_grade, "study_hours_30d": total_hours,
            "avg_productivity": avg_productivity,
            "consistency_score": round(float(patterns.get("consistency_score", 0)), 2),
            "metrics_updated_at": datetime.now(timezone.utc).isoformat()
        }).eq("id", profile["id"]).execute()
        return True, None
    except Exception as exc:
        return False, str(exc)

def classmates(course, semester):
    client = get_client()
    if not client:
        return []
    try:
        res = (client.table("profiles").select(
            "id,display_name,username,course,semester,avg_grade,study_hours_30d,avg_productivity,consistency_score,metrics_updated_at"
        ).eq("course_key", course_key(course)).eq("semester", int(semester))
         .order("avg_grade", desc=True).execute())
        return res.data or []
    except Exception:
        return []

def post_chat(message):
    client, profile = get_client(), online_profile()
    if not client or not profile:
        return False, "Sign in and complete your online profile first."
    message = message.strip()
    if not message:
        return False, "Message cannot be empty."
    if len(message) > 500:
        return False, "Keep messages under 500 characters."
    try:
        client.table("public_chat").insert({
            "user_id": profile["id"], "username": profile["username"],
            "course_key": profile["course_key"], "semester": profile["semester"],
            "message": message
        }).execute()
        return True, None
    except Exception as exc:
        return False, str(exc)

def fetch_chat(course, semester, limit=80):
    client = get_client()
    if not client:
        return []
    try:
        res = (client.table("public_chat").select("id,username,message,created_at")
               .eq("course_key", course_key(course)).eq("semester", int(semester))
               .order("created_at", desc=True).limit(limit).execute())
        return list(reversed(res.data or []))
    except Exception:
        return []

def create_battle(course, semester, questions):
    client, profile = get_client(), online_profile()
    if not client or not profile:
        return None, "Sign in and complete your online profile first."
    try:
        res = client.rpc("create_battle", {
            "p_course_key": course_key(course), "p_semester": int(semester),
            "p_creator_name": profile["username"], "p_questions": questions
        }).execute()
        return (res.data[0] if isinstance(res.data, list) and res.data else res.data), None
    except Exception as exc:
        return None, str(exc)

def open_battles(course, semester):
    client, uid = get_client(), online_user_id()
    if not client or not uid:
        return []
    try:
        res = (client.table("battles").select("id,creator_name,course_key,semester,status,created_at")
               .eq("course_key", course_key(course)).eq("semester", int(semester))
               .eq("status", "waiting").neq("creator_id", uid)
               .order("created_at", desc=True).limit(20).execute())
        return res.data or []
    except Exception:
        return []

def join_battle(battle_id):
    client = get_client()
    if not client:
        return False, "Online services are not configured."
    try:
        res = client.rpc("join_battle", {"p_battle_id": battle_id}).execute()
        return (True, None) if res.data else (False, "That battle was already joined or is unavailable.")
    except Exception as exc:
        return False, str(exc)

def get_battle(battle_id):
    client = get_client()
    if not client:
        return None
    try:
        res = client.table("battles").select("*").eq("id", battle_id).limit(1).execute()
        return res.data[0] if res.data else None
    except Exception:
        return None

def submit_answer(battle_id, question_index, answer_index):
    client = get_client()
    if not client or not online_user_id():
        return False, "Sign in first."
    try:
        client.rpc("submit_battle_answer", {
            "p_battle_id": battle_id, "p_question_index": int(question_index),
            "p_answer_index": int(answer_index)
        }).execute()
        return True, None
    except Exception as exc:
        return False, str(exc)

def battle_answers(battle_id):
    client = get_client()
    if not client:
        return []
    try:
        res = client.table("battle_answers").select("id,battle_id,user_id,question_index,answer_index,correct,created_at").eq("battle_id", battle_id).order("question_index").execute()
        return res.data or []
    except Exception:
        return []

def finish_battle(battle_id):
    client = get_client()
    uid = online_user_id()
    if not client or not uid:
        return False
    try:
        client.rpc("finish_battle", {"p_battle_id": battle_id}).execute()
        return True
    except Exception:
        return False
