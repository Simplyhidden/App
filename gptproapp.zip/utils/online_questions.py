import random
QUESTION_BANK = [
    {"q":"Which unit is used for frequency?","options":["Hertz","Newton","Joule","Watt"],"answer":0},
    {"q":"What is the derivative of x²?","options":["x","2x","x²","2"],"answer":1},
    {"q":"Binary 1010 is equal to decimal?","options":["8","9","10","12"],"answer":2},
    {"q":"Which data structure follows FIFO?","options":["Stack","Queue","Tree","Heap"],"answer":1},
    {"q":"The SI unit of resistance is?","options":["Ohm","Volt","Ampere","Farad"],"answer":0},
    {"q":"A flip-flop stores how many bits?","options":["1","2","4","8"],"answer":0},
    {"q":"Which gate gives 1 only when both inputs are 1?","options":["OR","XOR","AND","NOR"],"answer":2},
    {"q":"What is the value of sin(0)?","options":["0","1","-1","Undefined"],"answer":0},
    {"q":"Which protocol is commonly used for secure web browsing?","options":["HTTP","HTTPS","FTP","SMTP"],"answer":1},
    {"q":"Which component stores energy in an electric field?","options":["Resistor","Capacitor","Inductor","Diode"],"answer":1},
    {"q":"The sampling theorem is commonly associated with?","options":["Nyquist","Ohm","Kirchhoff","Faraday"],"answer":0},
    {"q":"What does CPU stand for?","options":["Central Processing Unit","Computer Power Unit","Core Program Utility","Central Program User"],"answer":0},
]
def make_questions(count=5):
    pool=QUESTION_BANK[:]
    random.shuffle(pool)
    # Store no answer key in the UI-visible battle payload after creation is sanitized in SQL RPC.
    return [{"q":x["q"],"options":x["options"],"answer":x["answer"]} for x in pool[:count]]
