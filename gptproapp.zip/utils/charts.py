"""
utils/charts.py  –  All reusable Plotly chart builders.
"""

import plotly.graph_objects as go
import plotly.express as px
import pandas as pd
from typing import Optional


def radar_chart(scores: dict) -> go.Figure:
    labels = list(scores.keys())
    values = list(scores.values())
    values_closed = values + [values[0]]
    labels_closed = labels + [labels[0]]

    fig = go.Figure()
    fig.add_trace(go.Scatterpolar(
        r=values_closed,
        theta=labels_closed,
        fill='toself',
        fillcolor='rgba(99,110,250,0.25)',
        line=dict(color='rgb(99,110,250)', width=2),
        name='Your Score'
    ))
    # Benchmark ring at 7
    benchmark = [7] * len(labels)
    benchmark_closed = benchmark + [benchmark[0]]
    fig.add_trace(go.Scatterpolar(
        r=benchmark_closed,
        theta=labels_closed,
        mode='lines',
        line=dict(color='rgba(255,165,0,0.6)', width=1.5, dash='dash'),
        name='Benchmark (7/10)'
    ))
    fig.update_layout(
        polar=dict(radialaxis=dict(visible=True, range=[0, 10])),
        showlegend=True,
        title="Performance Radar",
        height=420,
        margin=dict(t=60, b=20),
    )
    return fig


def study_hours_bar(daily_totals: list) -> go.Figure:
    if not daily_totals:
        return _empty("No study logs yet.")
    df = pd.DataFrame(daily_totals).sort_values("log_date")
    fig = px.bar(
        df, x="log_date", y="total_hours",
        color="avg_productivity",
        color_continuous_scale="Blues",
        labels={"log_date": "Date", "total_hours": "Hours Studied", "avg_productivity": "Productivity"},
        title="Daily Study Hours (colour = productivity)"
    )
    fig.update_layout(height=320, margin=dict(t=50, b=20))
    return fig


def productivity_trend(daily_totals: list) -> go.Figure:
    if not daily_totals:
        return _empty("No data yet.")
    df = pd.DataFrame(daily_totals).sort_values("log_date")
    fig = go.Figure()
    fig.add_trace(go.Scatter(
        x=df["log_date"], y=df["avg_productivity"],
        mode="lines+markers", name="Productivity",
        line=dict(color="#6366f1", width=2)
    ))
    fig.add_hline(y=7, line_dash="dash", line_color="orange",
                  annotation_text="Target (7)")
    fig.update_layout(
        title="Productivity Trend",
        xaxis_title="Date", yaxis_title="Productivity (1-10)",
        height=300, margin=dict(t=50, b=20), yaxis_range=[0, 10]
    )
    return fig


def grade_history(grades: list) -> go.Figure:
    if not grades:
        return _empty("No grades recorded yet.")
    df = pd.DataFrame(grades).sort_values("grade_date")
    fig = px.line(
        df, x="grade_date", y="grade", color="subject_name",
        markers=True,
        labels={"grade_date": "Date", "grade": "Grade (%)", "subject_name": "Subject"},
        title="Grade History by Subject"
    )
    fig.add_hline(y=80, line_dash="dot", line_color="gray",
                  annotation_text="Default target (80%)")
    fig.update_layout(height=340, margin=dict(t=50, b=20), yaxis_range=[0, 105])
    return fig


def subject_hours_pie(study_summary: list) -> go.Figure:
    if not study_summary:
        return _empty("No study data yet.")
    df = pd.DataFrame(study_summary)
    df = df[df["total_hours"] > 0]
    if df.empty:
        return _empty("No study hours logged.")
    fig = px.pie(df, names="subject_name", values="total_hours",
                 title="Study Time Distribution")
    fig.update_layout(height=320, margin=dict(t=50, b=20))
    return fig


def physical_vs_productivity(physical_logs: list, daily_totals: list) -> go.Figure:
    if not physical_logs or not daily_totals:
        return _empty("Need both physical and study logs for correlation.")
    phys_df  = pd.DataFrame(physical_logs)[["log_date","exercise_mins","sleep_hours"]]
    study_df = pd.DataFrame(daily_totals)[["log_date","avg_productivity"]]
    merged   = phys_df.merge(study_df, on="log_date", how="inner")
    if merged.empty:
        return _empty("No overlapping dates yet.")
    fig = px.scatter(
        merged, x="exercise_mins", y="avg_productivity",
        size="sleep_hours", color="sleep_hours",
        color_continuous_scale="Teal",
        labels={"exercise_mins": "Exercise (mins)", "avg_productivity": "Productivity",
                "sleep_hours": "Sleep (hrs)"},
        title="Exercise vs Productivity (bubble size = sleep)"
    )
    fig.update_layout(height=340, margin=dict(t=50, b=20))
    return fig


def comparison_bar(grades: list, benchmark_avg: float = 70.0, topper: float = 92.0) -> go.Figure:
    if not grades:
        return _empty("No grades to compare.")
    subjects = [g["subject_name"] for g in grades]
    your     = [g["grade"]        for g in grades]
    bench    = [benchmark_avg] * len(grades)
    top      = [topper]        * len(grades)

    fig = go.Figure(data=[
        go.Bar(name="Your Grade",  x=subjects, y=your,  marker_color="#6366f1"),
        go.Bar(name="Avg (Class)", x=subjects, y=bench, marker_color="#94a3b8"),
        go.Bar(name="Topper",      x=subjects, y=top,   marker_color="#f59e0b"),
    ])
    fig.update_layout(
        barmode="group", title="You vs Class Average vs Topper",
        yaxis_range=[0, 105], height=360, margin=dict(t=50, b=20)
    )
    return fig


def weekly_hours_heatmap(study_logs: list) -> go.Figure:
    """Simple calendar-style bar chart of last 4 weeks."""
    if not study_logs:
        return _empty("No logs yet.")
    df = pd.DataFrame(study_logs)
    df["log_date"] = pd.to_datetime(df["log_date"])
    weekly = df.groupby(df["log_date"].dt.to_period("W").astype(str))["hours_studied"].sum().reset_index()
    weekly.columns = ["week", "total_hours"]
    fig = px.bar(weekly.tail(8), x="week", y="total_hours",
                 labels={"week": "Week #", "total_hours": "Total Hours"},
                 title="Weekly Study Volume")
    fig.update_layout(height=300, margin=dict(t=50, b=20))
    return fig


def _empty(msg: str) -> go.Figure:
    fig = go.Figure()
    fig.add_annotation(text=msg, xref="paper", yref="paper",
                       x=0.5, y=0.5, showarrow=False, font=dict(size=14, color="gray"))
    fig.update_layout(height=250, xaxis_visible=False, yaxis_visible=False)
    return fig
