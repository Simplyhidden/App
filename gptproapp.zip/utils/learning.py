"""Offline, explainable scheduling. No model or network needed."""
import json
from datetime import date, timedelta
from utils.database import _conn, get_subjects, get_latest_grade_per_subject


def init_learning():
    with _conn() as con:
        con.executescript('''
        CREATE TABLE IF NOT EXISTS learning_settings (
          user_id INTEGER PRIMARY KEY REFERENCES users(id), goal TEXT NOT NULL,
          minutes INTEGER NOT NULL, deadline TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS learning_tasks (
          id INTEGER PRIMARY KEY, user_id INTEGER REFERENCES users(id),
          subject_id INTEGER REFERENCES subjects(id) ON DELETE CASCADE,
          study_date TEXT NOT NULL, minutes INTEGER NOT NULL, task TEXT NOT NULL,
          done INTEGER NOT NULL DEFAULT 0, confidence INTEGER,
          UNIQUE(user_id, subject_id, study_date));
        ''')


def settings(uid):
    init_learning()
    with _conn() as con:
        row = con.execute('SELECT * FROM learning_settings WHERE user_id=?', (uid,)).fetchone()
        return dict(row) if row else {'goal':'', 'minutes':60, 'deadline':str(date.today()+timedelta(days=30))}


def save_settings(uid, goal, minutes, deadline):
    if not goal.strip() or not 15 <= minutes <= 480 or date.fromisoformat(deadline) < date.today():
        raise ValueError('Enter a goal, 15–480 minutes, and a current or future deadline.')
    with _conn() as con:
        con.execute('INSERT OR REPLACE INTO learning_settings VALUES (?,?,?,?)', (uid, goal.strip(), minutes, deadline))


def gaps(uid):
    grades = {g['subject_id']:g['grade'] for g in get_latest_grade_per_subject(uid)}
    with _conn() as con:
        feedback = {r['subject_id']:r['confidence'] for r in con.execute('SELECT subject_id,confidence FROM learning_tasks WHERE user_id=? AND confidence IS NOT NULL ORDER BY study_date,id', (uid,))}
    rows=[]
    for s in get_subjects(uid):
        score = grades.get(s['id'])
        gap = max(0, s['target_grade']-score) if score is not None else None
        confidence = feedback.get(s['id'])
        priority = 10+(gap if gap is not None else 25)+(10-s['interest_level'])+((5-confidence)*5 if confidence else 0)
        rows.append({**s, 'latest':score, 'gap':gap, 'priority':priority,
          'reason':('No assessment yet: start with a diagnostic' if score is None else f'{gap:.0f} percentage points below target') + (f'; recall confidence {confidence}/5' if confidence else '')})
    return sorted(rows, key=lambda r:r['priority'], reverse=True)


def generate_plan(uid):
    cfg=settings(uid); subjects=gaps(uid)
    if not subjects: raise ValueError('Add subjects in My Profile first.')
    end=min(date.today()+timedelta(days=6), date.fromisoformat(cfg['deadline']))
    if end < date.today(): raise ValueError('Update your expired deadline before rebuilding the plan.')
    with _conn() as con:
        # Rebuild only unfinished work. Completed evidence is never discarded.
        con.execute('DELETE FROM learning_tasks WHERE user_id=? AND done=0 AND study_date>=?', (uid,str(date.today())))
        for offset in range((end-date.today()).days+1):
            day=str(date.today()+timedelta(days=offset))
            done=con.execute('SELECT subject_id,minutes FROM learning_tasks WHERE user_id=? AND study_date=? AND done=1', (uid,day)).fetchall()
            available=max(0,cfg['minutes']-sum(r['minutes'] for r in done))
            done_ids={r['subject_id'] for r in done}
            candidates=[s for s in subjects if s['id'] not in done_ids]
            if not candidates or available<15: continue
            # Weighted priority plus rotation gives low-priority subjects a turn.
            first=candidates[0]; rest=candidates[1:]
            chosen=[first]+([rest[offset % len(rest)]] if rest and available>=30 else [])
            base,extra=divmod(available,len(chosen))
            for i,s in enumerate(chosen):
                phase=['Diagnose: solve 3 questions without notes; record a grade.', 'Learn: review the weakest concept and work one example.', 'Practise: solve 5 questions and check your errors.', 'Recall: explain the concept without notes; revisit mistakes.'][offset % 4]
                con.execute('INSERT OR IGNORE INTO learning_tasks(user_id,subject_id,study_date,minutes,task) VALUES (?,?,?,?,?)',(uid,s['id'],day,base+(i<extra),phase))


def tasks(uid):
    with _conn() as con:
        return [dict(r) for r in con.execute('SELECT t.*,s.name FROM learning_tasks t JOIN subjects s ON s.id=t.subject_id WHERE t.user_id=? ORDER BY t.study_date,t.id',(uid,))]


def complete(uid, task_id, confidence):
    if confidence not in range(1,6): raise ValueError('Confidence must be 1–5.')
    with _conn() as con:
        con.execute('UPDATE learning_tasks SET done=1, confidence=? WHERE id=? AND user_id=?',(confidence,task_id,uid))
