import streamlit as st
def init_session():
    defaults={"user_id":None,"ai_chat_history":[],"online_user_id":None,"online_email":None,"battle_id":None}
    for k,v in defaults.items():
        if k not in st.session_state: st.session_state[k]=v
