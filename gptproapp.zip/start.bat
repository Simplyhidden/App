@echo off
setlocal
cd /d "%~dp0"
echo ================================================
echo       STUDY PERFORMANCE ANALYZER
echo ================================================
echo.
where py >nul 2>nul
if %errorlevel%==0 (set "PY=py") else (where python >nul 2>nul && set "PY=python")
if not defined PY (
 echo Python 3.10+ was not found. Install it from https://www.python.org/downloads/
 echo Make sure "Add Python to PATH" is checked.
 pause
 exit /b 1
)
if not exist "venv\Scripts\python.exe" (
 echo [1/3] Creating private environment...
 %PY% -m venv venv
 if errorlevel 1 goto error
)
echo [2/3] Checking packages...
if not exist "venv\.installed" (
 venv\Scripts\python.exe -m pip install -r requirements.txt
 if errorlevel 1 goto error
 echo ready>venv\.installed
)
echo [3/3] Starting Study Analyzer...
start "" http://localhost:8501
venv\Scripts\python.exe -m streamlit run app.py
exit /b 0
:error
echo Setup failed. Send the terminal error to the project owner.
pause
exit /b 1
