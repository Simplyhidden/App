-- Run after supabase_schema.sql, including on existing installations.
-- Scoring writes must go through authenticated, validated RPCs.
drop policy if exists battle_insert_own on public.battles;
drop policy if exists battle_update_participant on public.battles;
drop policy if exists answers_insert_own on public.battle_answers;
drop policy if exists answers_update_own on public.battle_answers;
create or replace function public.submit_battle_answer(p_battle_id uuid,p_question_index integer,p_answer_index integer)
returns public.battle_answers language plpgsql security definer set search_path=public as $$
declare b public.battles; ans public.battle_answers; correct_index integer;
begin
 select * into b from public.battles where id=p_battle_id and status='active'
 and (creator_id=auth.uid() or opponent_id=auth.uid()) for update;
 if b.id is null then raise exception 'Battle unavailable'; end if;
 if p_question_index<0 or p_question_index>=jsonb_array_length(b.questions) then raise exception 'Invalid question'; end if;
 if p_answer_index<0 or p_answer_index>=jsonb_array_length(b.questions->p_question_index->'options') then raise exception 'Invalid answer'; end if;
 select answer_index into correct_index from public.battle_question_keys where battle_id=b.id and question_index=p_question_index;
 if correct_index is null then raise exception 'Answer key missing'; end if;
 insert into public.battle_answers(battle_id,user_id,question_index,answer_index,correct)
 values(b.id,auth.uid(),p_question_index,p_answer_index,p_answer_index=correct_index)
 on conflict(battle_id,user_id,question_index) do nothing returning * into ans;
 if ans.id is null then raise exception 'Answer already submitted'; end if;
 return ans;
end; $$;
revoke all on function public.submit_battle_answer(uuid,integer,integer) from public;
grant execute on function public.submit_battle_answer(uuid,integer,integer) to authenticated;
create or replace function public.finish_battle(p_battle_id uuid)
returns boolean language plpgsql security definer set search_path=public as $$
declare b public.battles; n integer;
begin
 select * into b from public.battles where id=p_battle_id and (creator_id=auth.uid() or opponent_id=auth.uid()) for update;
 if b.id is null then raise exception 'Battle unavailable'; end if;
 select count(*) into n from public.battle_answers where battle_id=b.id and user_id in (b.creator_id,b.opponent_id);
 if n<>2*jsonb_array_length(b.questions) then raise exception 'Answers incomplete'; end if;
 update public.battles set status='finished' where id=b.id;
 return true;
end; $$;
revoke all on function public.finish_battle(uuid) from public;
grant execute on function public.finish_battle(uuid) to authenticated;
-- Match read/write permissions to course rooms, not merely client filters.
drop policy if exists chat_select_authenticated on public.public_chat;
create policy chat_select_authenticated on public.public_chat for select to authenticated using
(exists(select 1 from public.profiles p where p.id=auth.uid() and p.course_key=public_chat.course_key and p.semester=public_chat.semester));
drop policy if exists chat_insert_own on public.public_chat;
create policy chat_insert_own on public.public_chat for insert to authenticated with check
(exists(select 1 from public.profiles p where p.id=auth.uid() and p.id=public_chat.user_id and p.username=public_chat.username and p.course_key=public_chat.course_key and p.semester=public_chat.semester));
drop policy if exists answers_select_authenticated on public.battle_answers;
create policy answers_select_authenticated on public.battle_answers for select to authenticated using
(exists(select 1 from public.battles b where b.id=battle_answers.battle_id and (b.creator_id=auth.uid() or b.opponent_id=auth.uid())));
