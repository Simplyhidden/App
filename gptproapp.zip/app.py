import importlib.util
from pathlib import Path
import streamlit as st
from utils.database import init_db
from utils.session import init_session
st.set_page_config(page_title="Study Performance Analyzer",page_icon="📚",layout="wide",initial_sidebar_state="expanded")
init_db(); init_session()
st.sidebar.title("📚 Study Analyzer"); st.sidebar.markdown("---")
pages={
"🏠 Dashboard":"pages/dashboard.py","👤 My Profile":"pages/profile.py","📝 Daily Log":"pages/daily_log.py","📊 Performance":"pages/performance.py","🏃 Physical Activity":"pages/physical.py","🤖 AI Insights":"pages/ai_insights.py","📈 Comparisons":"pages/comparisons.py","🎯 Goals & Streaks":"pages/goals.py",
"🎯 Learning Path":"pages/learning_plan.py","🌐 Online Account":"pages/online_account.py","🏆 Compare Students":"pages/compare_students.py","💬 Public Chat":"pages/chat.py","⚔️ 1v1 Battle":"pages/battle.py"}
selection=st.sidebar.radio("Navigate",list(pages.keys()))
local_only=set(list(pages.keys())[:9])
if st.session_state.get("user_id") is None and selection in local_only and selection!="👤 My Profile":
    st.warning("👆 Please set up your profile first!"); selection="👤 My Profile"
page_file=str(Path(__file__).parent / pages[selection]); spec=importlib.util.spec_from_file_location("page",page_file); mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
st.sidebar.markdown("---")
if st.session_state.get("user_id"):
    from utils.database import get_user
    u=get_user(st.session_state["user_id"])
    if u: st.sidebar.success(f"Logged in as **{u['name']}**")
if st.session_state.get("online_user_id"): st.sidebar.info("🌐 Online community: signed in")
