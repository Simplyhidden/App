import streamlit as st
from utils.online import is_configured, online_profile, fetch_chat, post_chat
try:
    from streamlit_autorefresh import st_autorefresh
except ImportError:
    st_autorefresh=None
st.title("💬 Public Study Chat")
st.caption("Course/semester room. Please keep discussion respectful and never share passwords or private information.")
if not is_configured(): st.warning("Online mode is not configured."); st.stop()
profile=online_profile()
if not profile: st.info("Go to 🌐 Online Account and complete your profile first."); st.stop()
if st_autorefresh: st_autorefresh(interval=4000,key="chat_refresh")
messages=fetch_chat(profile["course"],profile["semester"],100)
box=st.container(height=500,border=True)
with box:
    if not messages: st.info("No messages yet. Start the discussion!")
    for m in messages:
        st.markdown(f"**{m['username']}** · `{str(m['created_at'])[:16].replace('T',' ')}`")
        st.write(m["message"]); st.markdown("---")
with st.form("chat_form",clear_on_submit=True):
    msg=st.text_input("Message",placeholder="Ask a question or help a classmate…",max_chars=500)
    if st.form_submit_button("Send 💬",type="primary"):
        ok,err=post_chat(msg)
        if ok: st.rerun()
        else: st.error(err)
