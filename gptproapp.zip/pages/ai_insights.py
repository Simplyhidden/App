import streamlit as st
from utils.database import (
    get_user, get_subjects, get_study_summary, get_daily_totals,
    get_latest_grade_per_subject, get_physical_logs, get_goals, get_grades
)
from utils.ai_engine import (
    analyze_study_patterns, compute_radar_scores,
    rule_based_insights, build_context_for_claude,
    ask_claude, generate_weekly_report
)

def safe_cloud(**kwargs):
    try:
        return ask_claude(**kwargs)
    except Exception:
        return "Cloud request failed. Check your connection, API key, model access and quota. Your local data is intact."

uid = st.session_state.get("user_id")
if not uid:
    st.stop()

user          = get_user(uid)
subjects      = get_subjects(uid)
summary       = get_study_summary(uid)
daily_totals  = get_daily_totals(uid, 30)
latest_grades = get_latest_grade_per_subject(uid)
physical_logs = get_physical_logs(uid, 30)
goals         = get_goals(uid)
all_grades    = get_grades(uid)

patterns = analyze_study_patterns(daily_totals, summary)
radar    = compute_radar_scores(summary, daily_totals, latest_grades, physical_logs, patterns)
context  = build_context_for_claude(user, subjects, patterns, radar, latest_grades, goals)
from utils.learning import settings, tasks
import json
context += "\nLearning goal and scheduled tasks:\n" + json.dumps({"settings":settings(uid),"tasks":tasks(uid)[-14:]})

st.title("🤖 AI Insights & Chat")

# ── Rule-based Insights (always available) ───────────────────────────────────
st.subheader("📌 Automated Insights")
tips = rule_based_insights(patterns, radar, latest_grades, subjects)
for tip in tips:
    st.markdown(f"- {tip}")

st.markdown("---")

# ── Claude API Chat ───────────────────────────────────────────────────────────
st.subheader("💬 Chat with Your AI Study Coach")

mode = st.radio("Coach mode", ["Offline guidance", "Local AI model", "Cloud AI (optional)"], horizontal=True)
st.caption("Offline guidance uses rules. Local AI runs on the computer hosting this app; opening it on a phone does not move inference to the phone.")
consent = False
if mode == "Cloud AI (optional)":
    consent = st.checkbox("Allow my learning context and chat to be sent to Anthropic")
with st.expander("🔑 Optional cloud API key"):
    api_key = st.text_input("Anthropic API Key", type="password",
                            placeholder="sk-ant-...",
                            help="Get your key at console.anthropic.com")
    if api_key:
        st.session_state["api_key"] = api_key
    st.caption("Your key is never stored — it stays in session memory only.")

api_key = st.session_state.get("api_key", "")

# Chat history display
if "ai_chat_history" not in st.session_state:
    st.session_state["ai_chat_history"] = []

for msg in st.session_state["ai_chat_history"]:
    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])

# Quick prompt buttons
st.markdown("**Quick prompts:**")
quick_cols = st.columns(4)
quick_prompts = [
    "What are my biggest weaknesses?",
    "Give me a study plan for next week",
    "Am I at risk of burnout?",
    "How can I improve my weakest subject?",
]
for i, qp in enumerate(quick_prompts):
    if quick_cols[i].button(qp, use_container_width=True):
        st.session_state["quick_prompt"] = qp
        st.rerun()

user_input = st.chat_input("Ask your AI coach anything...")

# Handle quick prompt
if "quick_prompt" in st.session_state:
    user_input = st.session_state.pop("quick_prompt")

if user_input:
    st.session_state["ai_chat_history"].append({"role": "user", "content": user_input})
    with st.chat_message("user"):
        st.markdown(user_input)

    with st.chat_message("assistant"):
        if mode == "Offline guidance":
            response = "**Offline guidance (rule-based):**\n\n" + "\n".join(tips) + "\n\nOpen Learning Path to build a plan around your deadline. This mode does not answer general questions."
        elif mode == "Local AI model":
            try:
                from utils.local_model import reply
                with st.spinner("Running the local model…"):
                    response, metrics = reply(context, user_input, st.session_state["ai_chat_history"][:-1])
                st.session_state["inference_metrics"] = metrics
            except Exception as exc:
                response = f"Local inference unavailable: {exc}. Offline guidance remains available; no cloud request was made."
        elif not api_key or not consent:
            response = (
                "Enable cloud consent and provide a key to use cloud chat.\n\n"
                "In the meantime, check the **Automated Insights** above for rule-based analysis."
            )
        else:
            with st.spinner("Thinking..."):
                response = safe_cloud(
                    context=context,
                    user_question=user_input,
                    chat_history=st.session_state["ai_chat_history"][:-1],
                    api_key=api_key,
                )
        st.markdown(response)
        st.session_state["ai_chat_history"].append({"role": "assistant", "content": response})

# ── Weekly Report ─────────────────────────────────────────────────────────────
st.markdown("---")
st.subheader("📄 AI Weekly Report")
if st.button("🔄 Generate Weekly Report", type="primary"):
    st.session_state["weekly_report"] = "## Study summary\n" + "\n".join(tips)
if st.session_state.get("weekly_report"):
    st.markdown(st.session_state["weekly_report"])
if st.session_state.get("inference_metrics"):
    import json
    with st.expander("Local inference measurements"):
        st.json(st.session_state["inference_metrics"])
        st.download_button("Export benchmark", json.dumps(st.session_state["inference_metrics"],indent=2),"benchmark.json","application/json")

if st.button("🗑 Clear Chat History"):
    st.session_state["ai_chat_history"] = []
    st.rerun()
