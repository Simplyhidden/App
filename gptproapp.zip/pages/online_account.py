import streamlit as st
from utils.online import is_configured, sign_up, sign_in, sign_out, online_user_id, online_profile, save_profile, sync_local_metrics
from utils.database import get_user

st.title("🌐 Online Account")
st.caption("One account for shared comparison, chat and 1v1 battles across devices.")
if not is_configured():
    st.warning("Online mode is not configured on this copy.")
    st.info("The original Study Analyzer remains fully usable locally. To enable shared features, follow SETUP_ONLINE.md.")
    st.stop()
if not online_user_id():
    t1,t2=st.tabs(["🔐 Sign in","✨ Create account"])
    with t1:
        with st.form("login"):
            email=st.text_input("Email"); password=st.text_input("Password",type="password")
            if st.form_submit_button("Sign in",type="primary"):
                user,err=sign_in(email,password)
                if err: st.error(err)
                else: st.success("Signed in!"); st.rerun()
    with t2:
        with st.form("signup"):
            email=st.text_input("Email",key="su_email"); password=st.text_input("Password (8+ characters)",type="password",key="su_pw"); confirm=st.text_input("Confirm password",type="password")
            if st.form_submit_button("Create account",type="primary"):
                if len(password)<8: st.error("Use at least 8 characters.")
                elif password!=confirm: st.error("Passwords do not match.")
                else:
                    user,err=sign_up(email,password)
                    if err: st.info(err)
                    else: st.success("Account created!"); st.rerun()
    st.stop()
profile=online_profile(); local_uid=st.session_state.get("user_id"); local_user=get_user(local_uid) if local_uid else None
c1,c2=st.columns([3,1]); c1.success(f"Signed in as **{profile.get('username') if profile else 'online user'}**")
if c2.button("Sign out"): sign_out(); st.rerun()
st.markdown("---"); st.subheader("👤 Community Profile")
with st.form("community_profile"):
    display=st.text_input("Display name",value=(profile or {}).get("display_name",local_user["name"] if local_user else ""))
    username=st.text_input("Username",value=(profile or {}).get("username",""),help="3–24 letters, numbers or underscore")
    course=st.text_input("Course",value=(profile or {}).get("course",local_user["course"] if local_user else ""))
    semester=st.number_input("Semester",1,12,int((profile or {}).get("semester",4)))
    if st.form_submit_button("Save online profile",type="primary"):
        ok,err=save_profile(display,username,course,int(semester))
        if ok: st.success("Profile saved."); st.rerun()
        else: st.error(err)
profile=online_profile()
if profile:
    st.markdown("---"); st.subheader("☁️ Publish Performance Snapshot")
    st.caption("Only aggregate metrics are shared: average grade, 30-day study hours, productivity and consistency.")
    if local_uid:
        if st.button("Sync my current analytics",type="primary"):
            ok,err=sync_local_metrics(local_uid)
            if ok: st.success("Snapshot synced."); st.rerun()
            else: st.error(err)
    else: st.info("Load your local profile first, then sync your analytics.")
