import streamlit as st
from datetime import date
from utils.database import log_physical, get_physical_logs, get_daily_totals
from utils.charts import physical_vs_productivity
import plotly.express as px
import pandas as pd

uid = st.session_state.get("user_id")
if not uid:
    st.stop()

st.title("🏃 Physical Activity Tracker")
st.caption("Track activity alongside your study habits. Correlation does not establish cause.")

# ── Log Physical ─────────────────────────────────────────────────────────────
with st.form("phys_log"):
    st.subheader("Log Today's Activity")
    c1, c2, c3, c4 = st.columns(4)
    log_date    = c1.date_input("Date", date.today())
    steps       = c2.number_input("Steps", 0, 100000, 0, 500)
    ex_mins     = c3.number_input("Exercise (mins)", 0, 300, 0, 5)
    sleep_hrs   = c4.number_input("Sleep (hours)", 0.0, 24.0, 7.0, 0.5)
    if st.form_submit_button("💾 Save Activity", type="primary"):
        log_physical(uid, str(log_date), int(steps), int(ex_mins), float(sleep_hrs))
        st.success("Activity logged!")
        st.rerun()

st.markdown("---")

phys_logs = get_physical_logs(uid, 30)
daily     = get_daily_totals(uid, 30)

if phys_logs:
    df = pd.DataFrame(phys_logs).sort_values("log_date")

    col1, col2, col3 = st.columns(3)
    col1.metric("Avg Steps/Day",    f"{df['steps'].mean():,.0f}")
    col2.metric("Avg Exercise/Day", f"{df['exercise_mins'].mean():.0f} min")
    col3.metric("Avg Sleep",        f"{df['sleep_hours'].mean():.1f} hrs")

    st.subheader("📉 Correlation: Exercise vs Productivity")
    st.plotly_chart(physical_vs_productivity(phys_logs, daily), use_container_width=True)

    st.subheader("😴 Sleep Trend")
    fig_sleep = px.line(df, x="log_date", y="sleep_hours",
                        markers=True, title="Sleep Hours Over Time",
                        labels={"log_date":"Date","sleep_hours":"Hours"})
    fig_sleep.add_hline(y=7, line_dash="dash", line_color="green",
                        annotation_text="Recommended (7h)")
    fig_sleep.update_layout(height=280, yaxis_range=[0, 12])
    st.plotly_chart(fig_sleep, use_container_width=True)

    st.subheader("📋 Activity Log")
    show_df = df[["log_date","steps","exercise_mins","sleep_hours"]].copy()
    show_df.columns = ["Date","Steps","Exercise (min)","Sleep (hrs)"]
    st.dataframe(show_df[::-1], use_container_width=True, hide_index=True)
else:
    st.info("No physical logs yet. Start tracking above!")
