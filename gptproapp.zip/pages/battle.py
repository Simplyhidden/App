import streamlit as st
from utils.online import is_configured, online_profile, create_battle, open_battles, join_battle, get_battle, submit_answer, battle_answers, finish_battle
from utils.online_questions import make_questions
try:
    from streamlit_autorefresh import st_autorefresh
except ImportError:
    st_autorefresh=None
st.title("⚔️ Online 1v1 Battle")
st.caption("Same course + semester. Shared state refreshes automatically every few seconds.")
if not is_configured(): st.warning("Online mode is not configured."); st.stop()
profile=online_profile()
if not profile: st.info("Go to 🌐 Online Account and complete your profile first."); st.stop()
if st_autorefresh: st_autorefresh(interval=2500,key="battle_refresh")
if "battle_id" not in st.session_state: st.session_state["battle_id"]=None
battle_id=st.session_state.get("battle_id")
if not battle_id:
    st.subheader("🎮 Start a Battle")
    if st.button("⚡ Create 1v1 Battle",type="primary"):
        b,err=create_battle(profile["course"],profile["semester"],make_questions(5))
        if err: st.error(err)
        else: st.session_state["battle_id"]=b["id"]; st.rerun()
    st.markdown("---"); st.subheader("🔎 Open Battles")
    battles=open_battles(profile["course"],profile["semester"])
    if not battles: st.info("No open battles. Create one and wait for your partner.")
    for b in battles:
        c1,c2=st.columns([3,1]); c1.write(f"**{b['creator_name']}** · Battle #{str(b['id'])[:8]}")
        if c2.button("Join ⚔️",key=f"join_{b['id']}"):
            ok,err=join_battle(b["id"])
            if ok: st.session_state["battle_id"]=b["id"]; st.rerun()
            else: st.error(err)
    st.stop()

battle=get_battle(battle_id)
if not battle: st.error("Battle not found. Start another battle."); st.session_state["battle_id"]=None; st.stop()
is_creator=battle["creator_id"]==profile["id"]
is_opponent=battle.get("opponent_id")==profile["id"]
if battle["status"]=="waiting":
    st.info(f"Waiting for an opponent. Battle ID: `{battle_id}`")
    if st.button("Leave waiting battle"): st.session_state["battle_id"]=None; st.rerun()
    st.stop()
questions=battle.get("questions") or []
public_questions=[{"q":q["q"],"options":q["options"]} for q in questions]
answers=battle_answers(battle_id)
my_answers={a["question_index"]:a for a in answers if a["user_id"]==profile["id"]}
creator_answers=[a for a in answers if a["user_id"]==battle["creator_id"]]
opponent_answers=[a for a in answers if a.get("user_id")==battle.get("opponent_id")]
st.subheader(f"⚔️ {battle['creator_name']}  VS  {battle.get('opponent_name','Opponent')}")
a,b=st.columns(2); a.metric(battle["creator_name"],sum(1 for x in creator_answers if x["correct"])); b.metric(battle.get("opponent_name","Opponent"),sum(1 for x in opponent_answers if x["correct"]))
if len(my_answers)<len(public_questions):
    idx=len(my_answers); q=public_questions[idx]
    st.markdown(f"### Question {idx+1} / {len(public_questions)}"); st.write(q["q"])
    choice=st.radio("Choose an answer",q["options"],key=f"q_{battle_id}_{idx}")
    if st.button("Submit answer",type="primary"):
        ok,err=submit_answer(battle_id,idx,q["options"].index(choice))
        if ok: st.rerun()
        else: st.error(err)
else: st.success("You completed all questions. Waiting for the other player…")
if len(answers)>=len(public_questions)*2:
    cs=sum(1 for x in answers if x["user_id"]==battle["creator_id"] and x["correct"]); os=sum(1 for x in answers if x["user_id"]==battle["opponent_id"] and x["correct"])
    if battle["status"]!="finished": finish_battle(battle_id)
    st.markdown("---"); st.subheader("🏁 Final Result"); a,b=st.columns(2); a.metric(battle["creator_name"],f"{cs}/{len(public_questions)}"); b.metric(battle["opponent_name"],f"{os}/{len(public_questions)}")
    if cs==os: st.info("🤝 It's a draw!")
    elif (is_creator and cs>os) or (is_opponent and os>cs): st.success("🏆 You won!")
    else: st.warning("Good battle! Your opponent won this round.")
if st.button("Leave battle"): st.session_state["battle_id"]=None; st.rerun()
