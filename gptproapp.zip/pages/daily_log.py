import streamlit as st
from datetime import date
from utils.database import get_subjects, log_study, get_study_logs

uid = st.session_state.get("user_id")
if not uid:
    st.stop()

st.title("📝 Daily Study Log")

subjects = get_subjects(uid)
if not subjects:
    st.warning("Add subjects in My Profile first.")
    st.stop()

st.subheader(f"Log for {date.today().strftime('%B %d, %Y')}")

log_date = st.date_input("Date", value=date.today(), max_value=date.today())

existing_logs = {r["subject_id"]: r for r in get_study_logs(uid, 36500) if r["log_date"] == str(log_date)}
logs_saved = []
with st.form("daily_log"):
    st.markdown("### Study Sessions")
    for s in subjects:
        st.markdown(f"**{s['name']}**")
        c1, c2 = st.columns(2)
        hours   = c1.number_input(f"Hours studied",     0.0, 24.0, float(existing_logs.get(s["id"],{}).get("hours_studied",0)), 0.5, key=f"h_{s['id']}_{log_date}")
        prod    = c2.slider(f"Productivity (1-10)",     1,   10,   7,       key=f"p_{s['id']}_{log_date}")
        topics  = st.text_input(f"Topics covered (comma-separated)", value=", ".join(existing_logs.get(s["id"],{}).get("topics_covered",[])), key=f"t_{s['id']}_{log_date}")
        logs_saved.append((s["id"], hours, prod, topics))
        st.markdown("---")

    submitted = st.form_submit_button("💾 Save Today's Log", type="primary")
    if submitted:
        if sum(row[1] for row in logs_saved) > 24:
            st.error("Total study time cannot exceed 24 hours in a day.")
            st.stop()
        for subj_id, hours, prod, topics_raw in logs_saved:
            if hours > 0 or subj_id in existing_logs:
                topics_list = [t.strip() for t in topics_raw.split(",") if t.strip()]
                log_study(uid, subj_id, str(log_date), hours, prod, topics_list)
        st.success("✅ Log saved! Head to the Dashboard to see your updated analytics.")
        st.rerun()

# ── Recent Logs ─────────────────────────────────────────────────────────────
st.markdown("---")
st.subheader("📋 Recent Logs (last 30 days)")
recent = get_study_logs(uid, 30)
if recent:
    import pandas as pd
    df = pd.DataFrame(recent)[["log_date","subject_name","hours_studied","productivity","topics_covered"]]
    df["topics_covered"] = df["topics_covered"].apply(lambda x: ", ".join(x) if x else "—")
    df.columns = ["Date","Subject","Hours","Productivity","Topics"]
    st.dataframe(df, use_container_width=True, hide_index=True)
else:
    st.info("No logs yet. Fill in today's log above!")
