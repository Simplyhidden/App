import streamlit as st
from utils.database import (
    create_user, list_users, get_subjects,
    add_subject, update_subject, delete_subject, get_user
)

st.title("👤 My Profile")

# ── User Selection / Creation ───────────────────────────────────────────────
users = list_users()

st.subheader("Select or Create Profile")
tab_select, tab_create = st.tabs(["🔍 Select existing", "➕ Create new"])

with tab_select:
    if users:
        options = {f"{u['name']} ({u['course']}) · #{u['id']}": u["id"] for u in users}
        picked = st.selectbox("Choose your profile", list(options.keys()))
        if st.button("Load Profile", type="primary"):
            for key in ("ai_chat_history", "quick_prompt", "weekly_report", "inference_metrics"):
                st.session_state.pop(key, None)
            st.session_state["user_id"] = options[picked]
            st.success(f"Loaded profile: {picked}")
            st.rerun()
    else:
        st.info("No profiles yet. Create one in the next tab.")

with tab_create:
    with st.form("create_user"):
        name   = st.text_input("Your name")
        course = st.text_input("Course / Field of study (e.g. Computer Science B.Tech)")
        submit = st.form_submit_button("Create Profile", type="primary")
        if submit and name.strip() and course.strip():
            uid = create_user(name.strip(), course.strip())
            for key in ("ai_chat_history", "quick_prompt", "weekly_report", "inference_metrics"):
                st.session_state.pop(key, None)
            st.session_state["user_id"] = uid
            st.success(f"Profile created! Welcome, {name}.")
            st.rerun()

# ── Subject Management ──────────────────────────────────────────────────────
uid = st.session_state.get("user_id")
if not uid:
    st.warning("Load or create a profile first.")
    st.stop()

user = get_user(uid)
st.markdown("---")
st.subheader(f"📚 Subjects for {user['name']}")

subjects = get_subjects(uid)
if subjects:
    for s in subjects:
        with st.expander(f"📖 {s['name']}"):
            col1, col2, col3 = st.columns([2, 2, 1])
            new_int    = col1.slider("Interest level", 1, 10, int(s["interest_level"]), key=f"int_{s['id']}")
            new_target = col2.number_input("Target grade (%)", 0.0, 100.0, float(s["target_grade"]), key=f"tgt_{s['id']}")
            if col1.button("Save", key=f"sv_{s['id']}"):
                update_subject(s["id"], new_int, new_target)
                st.success("Updated!")
                st.rerun()
            confirm = st.checkbox("Delete this subject and its logs/grades", key=f"confirm_{s['id']}")
            if col3.button("🗑 Delete", key=f"del_{s['id']}", disabled=not confirm):
                delete_subject(s["id"])
                st.rerun()
else:
    st.info("No subjects yet. Add some below.")

st.markdown("---")
st.subheader("➕ Add Subject")
with st.form("add_subject"):
    sname    = st.text_input("Subject name")
    interest = st.slider("Interest level (1=low, 10=love it)", 1, 10, 7)
    target   = st.number_input("Target grade (%)", 0.0, 100.0, 75.0)
    if st.form_submit_button("Add Subject", type="primary") and sname.strip():
        add_subject(uid, sname.strip(), interest, target)
        st.success(f"Added {sname}!")
        st.rerun()
