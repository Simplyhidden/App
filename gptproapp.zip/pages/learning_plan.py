import json
from datetime import date
import streamlit as st
from utils.learning import settings,save_settings,gaps,generate_plan,tasks,complete
uid=st.session_state.get('user_id')
if not uid: st.info('Load your profile first.'); st.stop()
st.title('🎯 Personalised Learning Path')
st.caption('Your targets, interests and recall feedback shape a plan that works offline.')
cfg=settings(uid)
with st.form('learning_settings'):
    goal=st.text_input('What do you want to achieve?',cfg['goal'],placeholder='Prepare for DSP mid-sem / master Python basics')
    a,b=st.columns(2)
    minutes=a.number_input('Study minutes per day',15,480,int(cfg['minutes']),15)
    deadline=b.date_input('Target date',max(date.today(),date.fromisoformat(cfg['deadline'])),min_value=date.today())
    if st.form_submit_button('Save goal & rebuild 7-day plan',type='primary'):
        try:
            save_settings(uid,goal,minutes,str(deadline));generate_plan(uid);st.rerun()
        except ValueError as exc: st.error(str(exc))
st.subheader('📌 Skill gaps & priorities')
rows=gaps(uid)
if rows:
    st.dataframe([{'Subject':r['name'],'Latest (%)':r['latest'],'Target (%)':r['target_grade'],'Why this priority':r['reason']} for r in rows],hide_index=True,use_container_width=True)
else: st.info('Add your subjects in My Profile to begin.')
st.subheader('📅 Your learning pathway')
all_tasks=tasks(uid)
for t in all_tasks:
    if t['study_date'] < str(date.today()) and t['done']: continue
    with st.expander(f"{'✅' if t['done'] else '📚'} {t['study_date']} · {t['name']} · {t['minutes']} min"):
        st.write(t['task'])
        if not t['done']:
            confidence=st.slider('How well can you recall it? (self-assessed)',1,5,3,key=f"confidence_{uid}_{t['id']}")
            if st.button('Complete session',key=f"complete_{uid}_{t['id']}"):
                complete(uid,t['id'],confidence);st.rerun()
        else: st.caption(f"Completed · recall confidence {t['confidence']}/5")
st.caption('Rebuild after adding grades or recall feedback to adapt priorities. Completion does not automatically create study hours or an assessment grade.')
st.download_button('Download my learning plan',json.dumps({'goal':cfg,'tasks':all_tasks},indent=2),'learning-plan.json','application/json')
