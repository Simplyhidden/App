import pandas as pd
import streamlit as st
from utils.online import is_configured, online_profile, classmates, sync_local_metrics
st.title("🏆 Compare with Other Students")
st.caption("Same course + semester only. Only aggregate learning metrics are shown.")
if not is_configured(): st.warning("Online mode is not configured."); st.stop()
profile=online_profile()
if not profile: st.info("Go to 🌐 Online Account and complete your profile first."); st.stop()
if st.button("🔄 Sync my latest analytics"):
    uid=st.session_state.get("user_id")
    if uid: sync_local_metrics(uid)
    st.rerun()
rows=classmates(profile["course"],profile["semester"])
if not rows: st.info("No classmates yet. Ask your partner to use the same course wording and semester."); st.stop()
df=pd.DataFrame(rows)
for col in ["avg_grade","study_hours_30d","avg_productivity","consistency_score"]: df[col]=pd.to_numeric(df[col],errors="coerce")
valid=df.dropna(subset=["avg_grade"]).sort_values("avg_grade",ascending=False).reset_index(drop=True)
rank=None
if not valid.empty:
    hits=valid.index[valid["id"]==profile["id"]].tolist(); rank=hits[0]+1 if hits else None
c1,c2,c3,c4=st.columns(4); c1.metric("Students",len(rows)); c2.metric("Your Rank",f"#{rank}" if rank else "—"); c3.metric("Course",profile["course"]); c4.metric("Semester",profile["semester"])
st.markdown("---"); st.subheader("📊 Course Leaderboard")
show=valid[["display_name","username","avg_grade","study_hours_30d","avg_productivity","consistency_score"]].copy(); show.insert(0,"Rank",range(1,len(show)+1)); show.columns=["Rank","Name","Username","Avg Grade (%)","Study Hours (30d)","Productivity /10","Consistency /10"]
st.dataframe(show,use_container_width=True,hide_index=True)
if rank:
    me=valid[valid["id"]==profile["id"]].iloc[0]
    st.markdown("---"); st.subheader("📈 You vs Course")
    a,b,c=st.columns(3)
    a.metric("Average Grade",f"{me['avg_grade']:.1f}%",f"{me['avg_grade']-valid['avg_grade'].mean():+.1f}% vs course")
    if pd.notna(me["study_hours_30d"]): b.metric("30d Study Hours",f"{me['study_hours_30d']:.1f}",f"{me['study_hours_30d']-valid['study_hours_30d'].dropna().mean():+.1f}h vs course")
    if pd.notna(me["avg_productivity"]): c.metric("Productivity",f"{me['avg_productivity']:.1f}/10",f"{me['avg_productivity']-valid['avg_productivity'].dropna().mean():+.1f} vs course")
