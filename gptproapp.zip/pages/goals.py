import streamlit as st
from datetime import date
from utils.database import add_goal, get_goals, mark_goal, get_streak, get_daily_totals

uid = st.session_state.get("user_id")
if not uid:
    st.stop()

st.title("🎯 Goals & Streaks")

streak = get_streak(uid)
daily  = get_daily_totals(uid, 30)

# ── Streak Display ────────────────────────────────────────────────────────────
st.subheader("🔥 Study Streaks")
c1, c2, c3 = st.columns(3)
c1.metric("Current Streak",  f"{streak['current_streak']} days")
c2.metric("Longest Streak",  f"{streak['longest_streak']} days")
total_days = len([d for d in daily if d["total_hours"] > 0])
c3.metric("Days Studied (30d)", total_days)

# Streak visualization
if daily:
    st.markdown("**Last 14 days:**")
    last_14 = {d["log_date"]: d["total_hours"] for d in daily[:14]}
    from datetime import timedelta
    cells = ""
    for i in range(13, -1, -1):
        day_str = str(date.today() - timedelta(days=i))
        hours   = last_14.get(day_str, 0)
        color   = "#22c55e" if hours >= 2 else "#fbbf24" if hours > 0 else "#e5e7eb"
        cells  += f'<span style="display:inline-block;width:28px;height:28px;border-radius:4px;background:{color};margin:2px;title:{day_str}"></span>'
    st.markdown(
        f'<div style="margin:8px 0">{cells}</div>'
        '<p style="font-size:12px;color:gray;">🟢 2h+  🟡 &lt;2h  ⬜ None</p>',
        unsafe_allow_html=True
    )

st.markdown("---")

# ── Goals ─────────────────────────────────────────────────────────────────────
st.subheader("🎯 Your Goals")

with st.form("add_goal"):
    c1, c2 = st.columns([3, 1])
    title   = c1.text_input("New goal", placeholder="e.g. Score 85% in Physics by May")
    tdate   = c2.date_input("Target date", value=None)
    if st.form_submit_button("➕ Add Goal", type="primary") and title:
        add_goal(uid, title.strip(), str(tdate) if tdate else None)
        st.rerun()

goals = get_goals(uid)
if goals:
    pending  = [g for g in goals if not g["achieved"]]
    achieved = [g for g in goals if g["achieved"]]

    if pending:
        st.markdown("**📌 Active Goals**")
        for g in pending:
            col_g, col_btn = st.columns([5, 1])
            deadline = f" _(by {g['target_date']})_" if g["target_date"] else ""
            col_g.markdown(f"- {g['title']}{deadline}")
            if col_btn.button("✅", key=f"done_{g['id']}"):
                mark_goal(g["id"], True)
                st.success("Goal achieved! 🎉")
                st.rerun()

    if achieved:
        with st.expander(f"🏆 Completed Goals ({len(achieved)})"):
            for g in achieved:
                st.markdown(f"- ~~{g['title']}~~ ✅")
else:
    st.info("No goals yet. Add one above to stay motivated!")

# ── Motivational tip ──────────────────────────────────────────────────────────
st.markdown("---")
tips = [
    "🌟 Small consistent steps beat big inconsistent leaps.",
    "🧠 After 25 minutes of focused study, take a 5-min break (Pomodoro).",
    "😴 Sleep is when your brain consolidates what you learned. Prioritize it.",
    "📵 Study without your phone nearby — it increases focus by ~40%.",
    "🎯 Setting specific goals ('I'll finish Chapter 3 today') beats vague ones.",
]
import random
random.seed(date.today().toordinal())
st.info(random.choice(tips))
