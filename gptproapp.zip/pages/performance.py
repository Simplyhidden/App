import streamlit as st
from datetime import date
from utils.database import (
    get_subjects, add_grade, get_grades,
    get_latest_grade_per_subject, get_daily_totals, get_study_summary
)
from utils.charts import grade_history, comparison_bar, productivity_trend, weekly_hours_heatmap
from utils.ai_engine import analyze_study_patterns

uid = st.session_state.get("user_id")
if not uid:
    st.stop()

st.title("📊 Performance Analysis")

subjects = get_subjects(uid)
grades   = get_grades(uid)
latest   = get_latest_grade_per_subject(uid)
daily    = get_daily_totals(uid, 60)
summary  = get_study_summary(uid)
patterns = analyze_study_patterns(daily, summary)

# ── Add Grade ────────────────────────────────────────────────────────────────
with st.expander("➕ Record a Grade"):
    with st.form("add_grade"):
        cols = st.columns(4)
        subj_map = {s["name"]: s["id"] for s in subjects}
        subj     = cols[0].selectbox("Subject", list(subj_map.keys()))
        grade_v  = cols[1].number_input("Grade (%)", 0.0, 100.0, 75.0)
        assess   = cols[2].text_input("Assessment name (e.g. Midterm)")
        gdate    = cols[3].date_input("Date", value=date.today())
        if st.form_submit_button("Add Grade", type="primary") and subj:
            add_grade(uid, subj_map[subj], grade_v, assess, str(gdate))
            st.success("Grade recorded!")
            st.rerun()

st.markdown("---")

# ── Current vs Target ────────────────────────────────────────────────────────
if latest:
    st.subheader("🎯 Current Grade vs Target")
    cols = st.columns(len(latest))
    for i, g in enumerate(latest):
        delta = round(g["grade"] - g["target_grade"], 1)
        cols[i].metric(g["subject_name"], f"{g['grade']:.1f}%",
                       delta=f"{delta:+.1f}% vs target")

st.markdown("---")

# ── Charts ────────────────────────────────────────────────────────────────────
st.subheader("📈 Grade History")
st.plotly_chart(grade_history(grades), use_container_width=True)

st.subheader("🏆 You vs Benchmark vs Topper")
c1, c2 = st.columns(2)
bench  = c1.slider("Class Average (%)", 0.0, 100.0, 70.0)
topper = c2.slider("Topper Score (%)",  0.0, 100.0, 92.0)
st.plotly_chart(comparison_bar(latest, bench, topper), use_container_width=True)

col1, col2 = st.columns(2)
with col1:
    st.subheader("⚡ Productivity Trend")
    st.plotly_chart(productivity_trend(daily), use_container_width=True)
with col2:
    st.subheader("📅 Weekly Study Volume")
    from utils.database import get_study_logs
    all_logs = get_study_logs(uid, 60)
    st.plotly_chart(weekly_hours_heatmap(all_logs), use_container_width=True)

# ── Trend Summary ─────────────────────────────────────────────────────────────
st.markdown("---")
st.subheader("📌 Trend Summary")
trend = patterns.get("trend", "stable")
trend_icons = {"improving": "📈", "declining": "📉", "stable": "📊", "no_data": "—"}
st.markdown(f"""
| Metric | Value |
|---|---|
| Overall Trend | {trend_icons.get(trend,'')} {trend.capitalize()} |
| Avg Daily Hours | {patterns.get('avg_daily_hours', 0):.1f} hrs |
| Avg Productivity | {patterns.get('avg_productivity', 0):.1f}/10 |
| Burnout Risk | {patterns.get('burnout_risk','—').capitalize()} |
| Consistency | {patterns.get('consistency_score', 0):.0f}/10 |
""")

if grades:
    import pandas as pd
    st.markdown("---")
    st.subheader("📋 Full Grade History")
    df = pd.DataFrame(grades)[["grade_date","subject_name","assessment","grade","target_grade"]]
    df.columns = ["Date","Subject","Assessment","Grade (%)","Target (%)"]
    st.dataframe(df, use_container_width=True, hide_index=True)
