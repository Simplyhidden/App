import streamlit as st
import pandas as pd
from utils.database import get_grades, get_daily_totals, get_study_summary, get_latest_grade_per_subject
from utils.charts import grade_history, comparison_bar, study_hours_bar
from utils.ai_engine import analyze_study_patterns

uid = st.session_state.get("user_id")
if not uid:
    st.stop()

st.title("📈 Comparison Tracker")

grades  = get_grades(uid)
daily   = get_daily_totals(uid, 60)
summary = get_study_summary(uid)
latest  = get_latest_grade_per_subject(uid)
patterns= analyze_study_patterns(daily, summary)

# ── Self comparison: first half vs second half ────────────────────────────────
st.subheader("📊 Self Comparison: Early vs Recent Performance")
if len(daily) >= 14:
    half    = len(daily) // 2
    early   = daily[half:]
    recent  = daily[:half]
    e_avg_h = sum(d["total_hours"] for d in early)  / max(len(early), 1)
    r_avg_h = sum(d["total_hours"] for d in recent) / max(len(recent), 1)
    e_avg_p = sum(d["avg_productivity"] for d in early  if d["avg_productivity"]) / max(len(early), 1)
    r_avg_p = sum(d["avg_productivity"] for d in recent if d["avg_productivity"]) / max(len(recent), 1)

    cols = st.columns(4)
    cols[0].metric("Early Period Hours/Day",    f"{e_avg_h:.1f}")
    cols[1].metric("Recent Period Hours/Day",   f"{r_avg_h:.1f}",  delta=f"{r_avg_h-e_avg_h:+.1f}")
    cols[2].metric("Early Productivity",        f"{e_avg_p:.1f}/10")
    cols[3].metric("Recent Productivity",       f"{r_avg_p:.1f}/10", delta=f"{r_avg_p-e_avg_p:+.1f}")
else:
    st.info("Log at least 14 days of data to see self-comparison.")

st.markdown("---")
st.subheader("📈 Grade History Trend")
st.plotly_chart(grade_history(grades), use_container_width=True)

st.markdown("---")
st.subheader("🏆 You vs Class vs Topper")
c1, c2 = st.columns(2)
bench  = c1.slider("Class Average (%)",   0.0, 100.0, 68.0, key="bench2")
topper = c2.slider("Topper Score (%)",    0.0, 100.0, 93.0, key="topper2")
st.plotly_chart(comparison_bar(latest, bench, topper), use_container_width=True)

# ── Improvement %  ────────────────────────────────────────────────────────────
if grades:
    st.markdown("---")
    st.subheader("📌 Grade Improvement by Subject")
    df = pd.DataFrame(grades)
    df = df.sort_values("grade_date")
    rows = []
    for subj_id in df["subject_id"].unique():
        sub = df[df["subject_id"] == subj_id]
        if len(sub) >= 2:
            first = sub.iloc[0]["grade"]
            last  = sub.iloc[-1]["grade"]
            pct   = ((last - first) / first * 100) if first else 0
            rows.append({
                "Subject": sub.iloc[-1]["subject_name"],
                "First Grade": f"{first:.1f}%",
                "Latest Grade": f"{last:.1f}%",
                "Improvement": f"{pct:+.1f}%",
                "Status": "📈 Improving" if pct > 0 else "📉 Declining" if pct < 0 else "➡ Stable"
            })
    if rows:
        st.dataframe(pd.DataFrame(rows), use_container_width=True, hide_index=True)
    else:
        st.info("Need at least 2 grades per subject to compute improvement.")

# ── Gamification: Rank ────────────────────────────────────────────────────────
st.markdown("---")
st.subheader("🎮 Your Rank (simulated)")
overall = patterns.get("consistency_score", 5) * 0.4 + patterns.get("avg_productivity", 5) * 0.6

if overall >= 8:
    rank, badge = "🥇 Top 10%", "gold"
elif overall >= 6:
    rank, badge = "🥈 Top 30%", "silver"
elif overall >= 4:
    rank, badge = "🥉 Top 50%", "bronze"
else:
    rank, badge = "📚 Keep going!", "blue"

st.markdown(f"### {rank}")
st.progress(min(overall / 10, 1.0))
st.caption(f"Combined score: {overall:.1f}/10 based on consistency and productivity")
