import streamlit as st
from datetime import date
from utils.database import (
    get_user, get_study_summary, get_daily_totals,
    get_latest_grade_per_subject, get_physical_logs,
    get_streak, get_goals, get_grades
)
from utils.ai_engine import analyze_study_patterns, compute_radar_scores, rule_based_insights
from utils.charts import radar_chart, study_hours_bar, subject_hours_pie

uid = st.session_state.get("user_id")
if not uid:
    st.stop()

user          = get_user(uid)
summary       = get_study_summary(uid)
daily_totals  = get_daily_totals(uid, 30)
latest_grades = get_latest_grade_per_subject(uid)
physical_logs = get_physical_logs(uid, 30)
streak        = get_streak(uid)
goals         = get_goals(uid)
all_grades    = get_grades(uid)

patterns = analyze_study_patterns(daily_totals, summary)
radar    = compute_radar_scores(summary, daily_totals, latest_grades, physical_logs, patterns)
tips     = rule_based_insights(patterns, radar, latest_grades, [])

st.title(f"👋 Welcome back, {user['name']}!")
st.caption(f"Today: {date.today().strftime('%A, %B %d %Y')} · Course: {user['course']}")
st.markdown("---")

# ── KPI Row ────────────────────────────────────────────────────────────────
c1, c2, c3, c4, c5 = st.columns(5)
c1.metric("🔥 Streak",          f"{streak['current_streak']} days")
c2.metric("📚 Avg Daily Hours", f"{patterns.get('avg_daily_hours',0):.1f} h")
c3.metric("⚡ Avg Productivity", f"{patterns.get('avg_productivity',0):.1f}/10")
c4.metric("🎯 Consistency",     f"{patterns.get('consistency_score',0):.0f}/10")
c5.metric("📈 Trend",           patterns.get("trend","—").capitalize())

st.markdown("---")

# ── Radar + Quick Insights ─────────────────────────────────────────────────
col_r, col_i = st.columns([1.2, 1])

with col_r:
    st.plotly_chart(radar_chart(radar), use_container_width=True)

with col_i:
    st.subheader("🤖 Quick Insights")
    for tip in tips[:4]:
        st.markdown(f"- {tip}")
    open_goals = [g for g in goals if not g["achieved"]]
    if open_goals:
        st.markdown("---")
        st.markdown("**🎯 Active Goals**")
        for g in open_goals[:3]:
            st.markdown(f"- {g['title']}" + (f" _(by {g['target_date']})_" if g["target_date"] else ""))

# ── Charts Row ─────────────────────────────────────────────────────────────
st.markdown("---")
col_h, col_p = st.columns(2)
with col_h:
    st.plotly_chart(study_hours_bar(daily_totals), use_container_width=True)
with col_p:
    st.plotly_chart(subject_hours_pie(summary),    use_container_width=True)
