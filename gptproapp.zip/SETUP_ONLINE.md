# 🌐 Online Setup

The original pages remain local-first. Supabase powers the shared features: Online Account, same-course comparison, public chat and 1v1 battle.

## One-time project owner setup

1. Create a Supabase project.
2. Open **SQL Editor**.
3. Paste/run `supabase_schema.sql`.
4. Copy the project URL and the **anon/public** key.
5. For local testing, copy `.streamlit/secrets.toml.example` to `.streamlit/secrets.toml` and replace the placeholders.
6. Never use the service-role key in this application and never commit `secrets.toml`.

## Local test

Run `start.bat` or `venv\\Scripts\\python.exe -m streamlit run app.py`.
Open **🌐 Online Account**, create an account, then fill in display name, username, course and semester. Use the exact same course wording for classmates. Sync local analytics.

## Two-laptop test

Both laptops must use the same Supabase project. `localhost` is private to each laptop. For the easiest partner experience, deploy once and share the deployed URL.

## Deployment

The project can be deployed to a Streamlit-compatible host. Add these secrets in the host's secrets/settings:

```toml
SUPABASE_URL = "https://YOUR-PROJECT.supabase.co"
SUPABASE_ANON_KEY = "YOUR-SUPABASE-ANON-KEY"
```

Then your partner only needs a browser; no VS Code or Python is required.

## Security design

Supabase Auth handles passwords. RLS is enabled. Online comparison shares only aggregate metrics. Battle scoring is performed by a database function so the browser does not decide whether an answer is correct.

## Known prototype limitation

Chat and battle pages use polling (a few seconds), not WebSockets. This is suitable for a college project prototype. For production-scale real-time multiplayer, use Supabase Realtime/WebSockets with a dedicated frontend.
