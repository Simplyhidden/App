"""
seed_demo.py  –  Run this ONCE to populate demo data for testing.
Usage: python seed_demo.py
"""

import sys, os
sys.path.insert(0, os.path.dirname(__file__))

from utils.database import init_db, create_user, add_subject, log_study, add_grade, log_physical, add_goal
from datetime import date, timedelta
import random

random.seed(42)
init_db()

# Create demo user
uid = create_user("Alex Kumar", "B.Tech Computer Science")

# Subjects
s1 = add_subject(uid, "Data Structures",    interest=9, target=85.0)
s2 = add_subject(uid, "Mathematics",        interest=6, target=75.0)
s3 = add_subject(uid, "Operating Systems",  interest=7, target=80.0)
s4 = add_subject(uid, "Python Programming", interest=10, target=90.0)
s5 = add_subject(uid, "Computer Networks",  interest=5, target=70.0)

subjects = [s1, s2, s3, s4, s5]

# 30 days of study logs
today = date.today()
for d in range(29, -1, -1):
    log_date = str(today - timedelta(days=d))
    if random.random() < 0.85:  # 85% attendance
        for sid in random.sample(subjects, k=random.randint(2, 4)):
            hours = round(random.uniform(0.5, 3.5), 1)
            prod  = random.randint(5, 10)
            topics = random.choice([
                ["Linked Lists", "Binary Trees"],
                ["Recursion", "DP"],
                ["Process Scheduling"],
                ["Socket Programming"],
                ["TCP/IP"],
            ])
            log_study(uid, sid, log_date, hours, prod, topics)

    # Physical logs
    log_physical(uid, log_date,
                 steps=random.randint(2000, 12000),
                 exercise_mins=random.randint(0, 60),
                 sleep_hours=round(random.uniform(5.5, 8.5), 1))

# Grades over time
grade_data = [
    (s1, "Unit Test 1",  72, -21), (s1, "Unit Test 2",  78, -10), (s1, "Midterm", 84, -2),
    (s2, "Quiz 1",       65, -25), (s2, "Midterm",       70, -12),
    (s3, "Lab Exam",     76, -15), (s3, "Midterm",       80, -5),
    (s4, "Project 1",    88, -20), (s4, "Midterm",       91, -7),
    (s5, "Quiz 1",       62, -18), (s5, "Midterm",       68, -4),
]
for sid, assess, grade, delta in grade_data:
    add_grade(uid, sid, grade, assess, str(today + timedelta(days=delta)))

# Goals
add_goal(uid, "Score 90%+ in Python Programming",     str(today + timedelta(days=30)))
add_goal(uid, "Study at least 3 hours daily for a week", str(today + timedelta(days=7)))
add_goal(uid, "Complete all Data Structures assignments", str(today + timedelta(days=14)))

print(f"✅ Demo data created! User ID = {uid}")
print(f"   Open the app and select 'Alex Kumar' in the Profile page.")
