# Upgraded Study Analyzer
Start with UPGRADE_GUIDE.md for launch instructions, fixes, contest mapping and remaining work. LOCAL_AI.md explains the optional offline model runtime. Existing UI/colours are retained.
